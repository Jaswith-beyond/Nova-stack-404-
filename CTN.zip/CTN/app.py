from flask import Flask, request, redirect, url_for, render_template_string, session, flash, abort
import sqlite3
import math
from functools import wraps
from werkzeug.security import generate_password_hash, check_password_hash
from location_data import LOCATION_DATA, LOCATION_ALIASES

app = Flask(__name__)
app.secret_key = "change-this-secret-key-in-production"
DB = "campus_talent.db"

SKILLS = ["Python","Machine Learning","SQL","React","JavaScript","UI/UX","Embedded Systems","IoT","Data Analysis","CAD","Robotics","Arduino"]
INTERESTS = ["AI","Hackathons","Research","IoT","Robotics","Web Development","Startups","Data Science","Innovation"]
AVAILABILITY = [("weekday_evening", "Weekday evenings"), ("weekend", "Weekends")]
WORK_STYLES=[("early_bird","Early Bird"),("daytime","Daytime"),("evening","Evening"),("night_owl","Night Owl")]
COMMITMENTS=[("casual","Casual"),("moderate","Moderate"),("high","Highly committed")]
GOALS=[("passing","Just passing"),("good_grade","Good grade"),("a_grade","A-grade"),("portfolio","Portfolio"),("hackathon","Hackathon/competition"),("startup","Startup/business project"),("learning","Learning/skill development")]
COMMUNICATIONS=[("async","Mostly asynchronous"),("mixed","Mixed"),("sync","Frequent synchronous communication")]

CSS = r'''
:root{--bg:#f6f8fc;--surface:#fff;--surface-2:#f8fafc;--surface-3:#eef2ff;--text:#172033;--muted:#64748b;--primary:#2563eb;--primary2:#1d4ed8;--border:#e2e8f0;--success-bg:#dcfce7;--success-text:#166534;--danger-bg:#fee2e2;--danger-text:#991b1b;--info-bg:#eff6ff;--info-text:#1e40af;--input:#fff;--shadow:0 10px 30px rgba(15,23,42,.07);--hero1:#10264a;--hero2:#1e40af;--header:rgba(15,32,59,.96)}
html[data-theme="dark"]{--bg:#0b1120;--surface:#111827;--surface-2:#172033;--surface-3:#1e293b;--text:#e5e7eb;--muted:#a8b3c5;--primary:#60a5fa;--primary2:#3b82f6;--border:#2b3648;--success-bg:#12351f;--success-text:#a7f3b8;--danger-bg:#3a171a;--danger-text:#fecaca;--info-bg:#122b4d;--info-text:#bfdbfe;--input:#0f172a;--shadow:0 10px 30px rgba(0,0,0,.28);--hero1:#111c35;--hero2:#1d4ed8;--header:rgba(8,15,29,.97);color-scheme:dark}
*{box-sizing:border-box}html{background:var(--bg)}body{margin:0;font-family:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;background:var(--bg);color:var(--text);line-height:1.55;transition:background-color .15s,color .15s}
header{position:sticky;top:0;z-index:10;background:var(--header);backdrop-filter:blur(10px);color:#fff;border-bottom:1px solid rgba(255,255,255,.08)}
.nav{max-width:1180px;margin:auto;padding:15px 22px;display:flex;align-items:center;justify-content:space-between;gap:20px}.brand{font-weight:800;letter-spacing:-.3px}.brand span{color:#60a5fa}.navlinks{display:flex;align-items:center;gap:7px;flex-wrap:wrap}.navlinks a{color:#dbeafe;text-decoration:none;padding:8px 11px;border-radius:9px;font-size:14px}.navlinks a:hover{background:rgba(255,255,255,.1);color:#fff}
.theme-toggle{display:inline-flex;align-items:center;gap:7px;color:#fff;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.16);padding:8px 11px;border-radius:9px;font:inherit;font-size:14px;font-weight:700;cursor:pointer}.theme-toggle:hover{background:rgba(255,255,255,.16)}
main{max-width:1180px;margin:0 auto;padding:30px 22px 60px}.hero{background:linear-gradient(135deg,var(--hero1),var(--hero2));color:#fff;border-radius:24px;padding:46px;margin-bottom:24px;box-shadow:var(--shadow)}.hero h1{font-size:clamp(32px,5vw,56px);line-height:1.04;margin:0 0 15px;max-width:780px;letter-spacing:-1.8px}.hero p{max-width:700px;color:#dbeafe;font-size:18px}.actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:24px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:18px}.two{display:grid;grid-template-columns:1.2fr .8fr;gap:20px}@media(max-width:800px){.two{grid-template-columns:1fr}.nav{align-items:flex-start}.navlinks{justify-content:flex-end}}
.card{background:var(--surface);border:1px solid var(--border);border-radius:18px;padding:22px;box-shadow:var(--shadow);margin-bottom:18px}.card h2,.card h3{margin-top:0}.eyebrow{text-transform:uppercase;letter-spacing:1.2px;font-size:12px;font-weight:800;color:#93c5fd}.muted,.small{color:var(--muted)}
a{color:var(--primary)}a:hover{color:var(--primary2)}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:7px;background:var(--primary);color:#fff!important;padding:10px 15px;border-radius:10px;text-decoration:none;border:0;cursor:pointer;font-weight:700}.btn:hover{background:var(--primary2)}.btn.secondary{background:var(--surface-3);color:var(--primary2)!important;border:1px solid var(--border)}.btn.danger{background:var(--danger-bg);color:var(--danger-text)!important}.btn.ghost{background:transparent;color:#dbeafe!important;border:1px solid rgba(255,255,255,.2)}
input,select,textarea{width:100%;padding:11px 12px;border:1px solid var(--border);border-radius:10px;background:var(--input);color:var(--text);font:inherit;margin:6px 0 15px}input::placeholder,textarea::placeholder{color:var(--muted)}input:focus,select:focus,textarea:focus{outline:3px solid rgba(96,165,250,.25);border-color:#60a5fa}textarea{min-height:110px;resize:vertical}label{font-weight:700;font-size:14px}.form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:0 16px}@media(max-width:650px){.form-grid{grid-template-columns:1fr}}
.check-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:9px;margin:8px 0 18px}.check{display:flex;align-items:center;gap:8px;background:var(--surface-2);border:1px solid var(--border);padding:10px;border-radius:10px;font-weight:500}.check input{width:auto;margin:0}.skill-row{display:grid;grid-template-columns:1fr 120px;gap:10px;align-items:center}.badge{display:inline-block;background:var(--info-bg);color:var(--info-text);border:1px solid var(--border);border-radius:999px;padding:5px 9px;margin:3px;font-size:12px;font-weight:700}.score{font-size:32px;font-weight:900;color:var(--primary)}.scorebar{height:9px;background:var(--surface-3);border-radius:99px;overflow:hidden;margin:8px 0 15px}.scorebar i{display:block;height:100%;background:var(--primary);border-radius:99px}.rating{display:inline-flex;align-items:center;gap:5px;font-weight:800;color:#b45309}.stars{letter-spacing:2px;color:#f59e0b}.rating-card{background:linear-gradient(135deg,var(--surface-2),var(--surface));border:1px solid var(--border)}.rating-item{padding:14px 0;border-bottom:1px solid var(--border)}.rating-item:last-child{border-bottom:0}.notice{padding:12px 14px;border-radius:12px;margin-bottom:14px}.success{background:var(--success-bg);color:var(--success-text)}.error{background:var(--danger-bg);color:var(--danger-text)}.info{background:var(--info-bg);color:var(--info-text)}.stat{padding:18px;border-radius:15px;background:var(--surface-2);border:1px solid var(--border)}.stat b{display:block;font-size:28px}.row{display:flex;justify-content:space-between;gap:15px;align-items:center;flex-wrap:wrap}.divider{height:1px;background:var(--border);margin:20px 0}.empty{text-align:center;padding:35px 15px;color:var(--muted)}footer{max-width:1180px;margin:auto;padding:0 22px 30px;color:var(--muted);font-size:13px}
.table-wrap{overflow-x:auto}table{width:100%;border-collapse:collapse;background:var(--surface)}th,td{padding:10px 12px;border-bottom:1px solid var(--border);text-align:left}th{color:var(--muted);font-size:13px}tr:hover td{background:var(--surface-2)}
hr{border:0;border-top:1px solid var(--border)}.meter{display:grid;grid-template-columns:150px 1fr 55px;gap:10px;align-items:center;margin:9px 0}.meter-track{height:10px;border-radius:99px;background:var(--surface-3);overflow:hidden}.meter-track i{display:block;height:100%;background:var(--primary)}.dna-grid,.chem-grid,.skill-tree{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px}.dna,.chem{padding:15px;border:1px solid var(--border);border-radius:14px;background:var(--surface-2)}.dna b{font-size:25px}.skill-line{margin:10px 0}.mini-bar{height:7px;background:var(--surface-3);border-radius:99px;overflow:hidden}.mini-bar i{display:block;height:100%;background:var(--primary)}.stepper{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:20px}.step{padding:7px 12px;border-radius:99px;background:var(--surface-3);color:var(--muted);font-weight:700}.brief-step{display:none}.brief-step.active{display:block}.step-actions{display:flex;gap:10px;margin-top:20px}.step.active{background:var(--primary);color:#fff}.tip{padding:12px;background:var(--surface-2);border-left:3px solid var(--primary);border-radius:8px}
'''

LAYOUT = '''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="description" content="Campus Talent Network — connect students by skills, interests and availability."><script>(function(){try{var t=localStorage.getItem('ctn-theme');if(t==='dark'||t==='light')document.documentElement.setAttribute('data-theme',t);}catch(e){}})();</script><title>{{title}} · Campus Talent Network</title><style>''' + CSS + '''</style></head><body>
<header><div class="nav"><a class="brand" href="/" style="color:white;text-decoration:none">🎓 Campus <span>Talent</span> Network</a><nav class="navlinks"><a href="/">Home</a>{% if session.get('user_id') %}<a href="/dashboard">Dashboard</a><a href="/find-teammate">Teammates</a><a href="/projects">Projects</a><a href="/profile">Profile</a><a href="/logout">Logout</a>{% else %}<a href="/login">Login</a><a class="btn" href="/register">Join Network</a>{% endif %}<button id="themeToggle" class="theme-toggle" type="button" aria-label="Toggle color theme" title="Toggle dark/light mode"><span id="themeIcon">☀️</span><span id="themeLabel">Light</span></button></nav></div></header>
<main>{% with messages=get_flashed_messages(with_categories=true) %}{% for category,m in messages %}<div class="notice {{category}}">{{m}}</div>{% endfor %}{% endwith %}{{body|safe}}</main><footer>Campus Talent Network · Local student collaboration prototype</footer><script>(function(){const root=document.documentElement,btn=document.getElementById('themeToggle'),icon=document.getElementById('themeIcon'),label=document.getElementById('themeLabel');function theme(){return root.getAttribute('data-theme')==='dark'?'dark':'light'}function render(){const dark=theme()==='dark';icon.textContent=dark?'🌙':'☀️';label.textContent=dark?'Dark':'Light';btn.setAttribute('aria-pressed',String(dark));btn.setAttribute('title',dark?'Switch to light mode':'Switch to dark mode');}btn.addEventListener('click',function(){const next=theme()==='dark'?'light':'dark';root.setAttribute('data-theme',next);try{localStorage.setItem('ctn-theme',next);}catch(e){}render();});render();})();</script></body></html>
'''

def db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = db()
    conn.executescript('''
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,email TEXT UNIQUE NOT NULL,password TEXT NOT NULL,phone TEXT,branch TEXT,year INTEGER,availability TEXT,bio TEXT,banned INTEGER DEFAULT 0,location TEXT,state TEXT,district TEXT,latitude REAL,longitude REAL,work_style TEXT,commitment TEXT,goal TEXT,communication TEXT,working_start INTEGER,working_end INTEGER,theme TEXT DEFAULT 'light');
    CREATE TABLE IF NOT EXISTS skills(user_id INTEGER,skill TEXT,level INTEGER,PRIMARY KEY(user_id,skill));
    CREATE TABLE IF NOT EXISTS interests(user_id INTEGER,interest TEXT,PRIMARY KEY(user_id,interest));
    CREATE TABLE IF NOT EXISTS projects(id INTEGER PRIMARY KEY AUTOINCREMENT,owner_id INTEGER,title TEXT NOT NULL,description TEXT,required_skills TEXT,interests TEXT,availability TEXT,team_size INTEGER,problem TEXT,objective TEXT,preferred_skills TEXT,open_roles TEXT,time_hours INTEGER,duration_weeks INTEGER,deadline TEXT,work_pace TEXT,work_structure TEXT,communication TEXT,goal TEXT,commitment TEXT,personality TEXT,dna_difficulty INTEGER,dna_time INTEGER,dna_collaboration INTEGER,dna_pressure INTEGER);
    CREATE TABLE IF NOT EXISTS teammate_queries(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,search_text TEXT NOT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS experience_ratings(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        reviewer_id INTEGER NOT NULL,
        reviewed_id INTEGER NOT NULL,
        experience TEXT NOT NULL,
        rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
        comment TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(reviewer_id, reviewed_id, experience),
        CHECK(reviewer_id != reviewed_id)
    );
    CREATE TABLE IF NOT EXISTS user_reports(reporter_id INTEGER, reported_id INTEGER, PRIMARY KEY(reporter_id,reported_id));
    CREATE TABLE IF NOT EXISTS follows(
        follower_id INTEGER NOT NULL,
        following_id INTEGER NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY(follower_id, following_id),
        CHECK(follower_id != following_id)
    );
    CREATE TABLE IF NOT EXISTS project_members(
        project_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        role TEXT,
        responsibilities TEXT,
        joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY(project_id,user_id)
    );
    ''')
    columns={r["name"] for r in conn.execute("PRAGMA table_info(users)")}
    if "phone" not in columns: conn.execute("ALTER TABLE users ADD COLUMN phone TEXT")
    if "bio" not in columns: conn.execute("ALTER TABLE users ADD COLUMN bio TEXT")
    if "banned" not in columns: conn.execute("ALTER TABLE users ADD COLUMN banned INTEGER DEFAULT 0")
    if "location" not in columns: conn.execute("ALTER TABLE users ADD COLUMN location TEXT")
    if "state" not in columns: conn.execute("ALTER TABLE users ADD COLUMN state TEXT")
    if "district" not in columns: conn.execute("ALTER TABLE users ADD COLUMN district TEXT")
    if "latitude" not in columns: conn.execute("ALTER TABLE users ADD COLUMN latitude REAL")
    if "longitude" not in columns: conn.execute("ALTER TABLE users ADD COLUMN longitude REAL")
    for col,typ in {"work_style":"TEXT","commitment":"TEXT","goal":"TEXT","communication":"TEXT","working_start":"INTEGER","working_end":"INTEGER","theme":"TEXT DEFAULT 'light'"}.items():
        if col not in columns: conn.execute(f"ALTER TABLE users ADD COLUMN {col} {typ}")
    pcols={r["name"] for r in conn.execute("PRAGMA table_info(projects)")}
    for col,typ in {"problem":"TEXT","objective":"TEXT","preferred_skills":"TEXT","open_roles":"TEXT","time_hours":"INTEGER","duration_weeks":"INTEGER","deadline":"TEXT","work_pace":"TEXT","work_structure":"TEXT","communication":"TEXT","goal":"TEXT","commitment":"TEXT","personality":"TEXT","dna_difficulty":"INTEGER","dna_time":"INTEGER","dna_collaboration":"INTEGER","dna_pressure":"INTEGER"}.items():
        if col not in pcols: conn.execute(f"ALTER TABLE projects ADD COLUMN {col} {typ}")
    if conn.execute("SELECT COUNT(*) FROM projects").fetchone()[0]==0:
        conn.executemany("INSERT INTO projects(owner_id,title,description,required_skills,interests,availability,team_size) VALUES(NULL,?,?,?,?,?,?)",[
            ("Smart Campus IoT","Monitor classroom energy usage with connected sensors.","IoT:4,Python:3,Embedded Systems:3","IoT,Robotics","weekend",3),
            ("AI Student Assistant","Build an AI assistant for campus FAQs and student services.","Python:4,Machine Learning:4,SQL:3","AI,Research","weekday_evening",3),
            ("Campus Event App","Create a modern event discovery and registration platform.","React:4,JavaScript:4,UI/UX:3","Web Development,Hackathons","weekend",2)])
    conn.execute("UPDATE users SET location=NULL")
    conn.commit(); conn.close()

def login_required(f):
    @wraps(f)
    def wrapper(*args,**kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        # Immediately invalidate an active session if the account has reached
        # the 5-report threshold and has been banned.
        conn=db(); u=conn.execute("SELECT banned FROM users WHERE id=?",(session["user_id"],)).fetchone(); conn.close()
        if not u or u["banned"]:
            session.clear()
            flash("Your account has been permanently blocked after reaching the report threshold.","error")
            return redirect(url_for("login"))
        return f(*args,**kwargs)
    return wrapper

def user_data(uid):
    conn=db(); u=conn.execute("SELECT * FROM users WHERE id=?",(uid,)).fetchone()
    skills={r["skill"]:r["level"] for r in conn.execute("SELECT skill,level FROM skills WHERE user_id=? ORDER BY skill",(uid,))}
    interests={r["interest"] for r in conn.execute("SELECT interest FROM interests WHERE user_id=? ORDER BY interest",(uid,))}; conn.close()
    return u,skills,interests

def parse_project(p):
    req={}
    for item in (p["required_skills"] or "").split(","):
        if ":" in item:
            sk,l=item.split(":",1)
            try:req[sk.strip()]=safe_int(l,0,1,5)
            except ValueError: pass
    pref={}
    for item in (p["preferred_skills"] or "").split(","):
        if ":" in item:
            sk,l=item.split(":",1)
            try: pref[sk.strip()]=safe_int(l,0,1,5)
            except ValueError: pass
    ints={x.strip() for x in (p["interests"] or "").split(",") if x.strip()}
    av={x.strip() for x in (p["availability"] or "").split(",") if x.strip()}
    return req,pref,ints,av

def safe_int(value,default=0,low=None,high=None):
    try: n=int(value)
    except (TypeError,ValueError): return default
    if low is not None: n=max(low,n)
    if high is not None: n=min(high,n)
    return n

def pref_score(a,b):
    if not a or not b: return 70
    if a==b: return 100
    if a=="mixed" or b=="mixed": return 65
    return 35

def working_overlap(a_start,a_end,b_start,b_end):
    if None in (a_start,a_end,b_start,b_end): return 0
    def ints(s,e): return [(s,e)] if e>s else [(s,24),(0,e)]
    return min(100,sum(max(0,min(e,y)-max(st,x)) for st,e in ints(a_start,a_end) for x,y in ints(b_start,b_end))/24*100)

def parse_roles(text):
    out=[]
    for item in (text or "").split(";"):
        p=item.split("|")
        if p and p[0].strip(): out.append((p[0].strip(),p[1].strip() if len(p)>1 else ""))
    return out

def project_dna(p):
    req,_,_,_=parse_project(p)
    hours=safe_int(p["time_hours"],4,1,80); duration=safe_int(p["duration_weeks"],8,1,52); team=safe_int(p["team_size"],1,1,10)
    roles=len(parse_roles(p["open_roles"]))
    return {"difficulty":max(1,min(10,round(2+min(sum(req.values())/max(len(req),1),5)+min(len(req),5)*.5))),
            "time":max(1,min(10,round(1+hours/8+duration/8))),
            "collaboration":max(1,min(10,round(4+team*.7+roles*.4))),
            "pressure":min(10,5+(2 if p["deadline"] else 0)+(2 if p["work_pace"]=="fast" else 0)+(1 if duration<=4 else 0))}

def team_analysis(pid):
    conn=db(); p=conn.execute("SELECT * FROM projects WHERE id=?",(pid,)).fetchone()
    members=conn.execute("SELECT user_id,role FROM project_members WHERE project_id=?",(pid,)).fetchall(); conn.close()
    if not p: return None
    req,pref,_,_=parse_project(p); combined={}
    for m in members:
        _,sk,_=user_data(m["user_id"])
        for k,v in sk.items(): combined[k]=max(combined.get(k,0),v)
    gaps=[]
    for skill,need in {**req,**pref}.items():
        have=combined.get(skill,0); ratio=have/max(need,1)
        gaps.append({"skill":skill,"required":need,"have":have,"status":"Strong" if ratio>=.85 else ("Weak" if ratio>=.5 else "Missing")})
    return {"project":p,"member_ids":[m["user_id"] for m in members],"skills":combined,"gaps":gaps}

def complementary_fit(uid,required,member_ids):
    _,candidate,_=user_data(uid); covered={}
    for mid in member_ids:
        _,sk,_=user_data(mid)
        for k,v in sk.items(): covered[k]=max(covered.get(k,0),v)
    missing=[s for s,n in required.items() if covered.get(s,0)<n]
    if not missing: return 50
    return round(sum(min(candidate.get(s,0)/required[s],1) for s in missing)/len(missing)*100,1)

def project_compatibility(uid,pid):
    a=team_analysis(pid)
    if not a: return None
    p=a["project"]; u,sk,_=user_data(uid); req,pref,ints,pav=parse_project(p)
    technical=score_student(uid,req,ints,pav,p)
    complementary=complementary_fit(uid,req,a["member_ids"]) if a["member_ids"] else 70
    av={x.strip() for x in (u["availability"] or "").split(",") if x.strip()}
    availability=len(av&pav)/len(pav)*100 if pav else 70
    vals=[]
    for mid in a["member_ids"]:
        mu,_,_=user_data(mid); vals.append(working_overlap(u["working_start"],u["working_end"],mu["working_start"],mu["working_end"]))
    overlap=sum(vals)/len(vals) if vals else 70
    work=100 if u["work_style"] and p["work_pace"] and ((p["work_pace"]=="fast" and u["work_style"] in ("evening","night_owl")) or (p["work_pace"]=="relaxed" and u["work_style"] in ("daytime","early_bird"))) else 70
    communication=pref_score(u["communication"],p["communication"]); goal=pref_score(u["goal"],p["goal"]); commitment=pref_score(u["commitment"],p["commitment"])
    time=(availability+overlap)/2
    overall=round(.25*technical+.20*complementary+.12*work+.12*communication+.11*time+.10*goal+.10*commitment,1)
    missing=[g["skill"] for g in a["gaps"] if g["status"] in ("Missing","Weak")]
    filled=[x for x in missing if sk.get(x,0)>=next((g["required"] for g in a["gaps"] if g["skill"]==x),1)]
    reasons=[]
    if filled: reasons.append("Fills missing skill(s): "+", ".join(filled))
    if overlap>=70: reasons.append("Strong working-hour overlap ("+str(round(overlap))+"%)")
    if communication>=90: reasons.append("Communication preference aligns")
    if goal>=90: reasons.append("Goal aligns")
    if commitment>=90: reasons.append("Commitment level aligns")
    if not reasons: reasons.append("Relevant skills and compatible preferences")
    return {"overall":overall,"technical":round(technical,1),"complementary":complementary,"work":work,"communication":communication,"time":round(time,1),"goal":goal,"commitment":commitment,"overlap":round(overlap,1),"reasons":reasons}

def score_student(uid,required,project_interests,project_availability,project=None):
    u,skills,interests=user_data(uid)
    max_points=sum(required.values())
    skill=(sum(min(skills.get(s,0)/lvl,1)*lvl for s,lvl in required.items())/max_points*100) if max_points else 70
    interest=(len(interests&project_interests)/len(project_interests)*100) if project_interests else 70
    av={x.strip() for x in (u["availability"] or "").split(",") if x.strip()}
    availability=len(av&project_availability)/len(project_availability)*100 if project_availability else 70
    if not project: return round(.60*skill+.25*interest+.15*availability,1)
    return round(.45*skill+.15*interest+.10*availability+.10*(100 if u["work_style"] and project["work_pace"] else 70)+.08*pref_score(u["communication"],project["communication"])+.06*pref_score(u["goal"],project["goal"])+.06*pref_score(u["commitment"],project["commitment"]),1)

def get_experience_summary(uid):
    conn=db()
    row=conn.execute('SELECT AVG(rating) AS avg_rating, COUNT(*) AS count FROM experience_ratings WHERE reviewed_id=?',(uid,)).fetchone()
    recent=conn.execute('SELECT er.*, u.name AS reviewer_name FROM experience_ratings er JOIN users u ON u.id=er.reviewer_id WHERE er.reviewed_id=? ORDER BY er.id DESC LIMIT 5',(uid,)).fetchall()
    conn.close()
    return (round(row['avg_rating'],1) if row['avg_rating'] is not None else None, row['count'], recent)

def find_teammates(uid, query="", limit=10):
    """Rank teammates. Multiple attributes can be searched with commas, e.g.
    ``CAD, Python, Robotics``. A candidate matching more requested attributes
    is ranked higher; for a searched skill, its skill rating contributes to the
    attribute score. Location, team experience and compatibility break ties.
    """
    me,my_skills,my_interests=user_data(uid)
    my_names=set(my_skills)
    my_av={x.strip() for x in (me["availability"] or "").split(",") if x.strip()}
    raw=(query or "").strip()
    tokens=[t.strip().casefold() for t in raw.replace(";",",").split(",") if t.strip()]
    conn=db(); ids=[r["id"] for r in conn.execute("SELECT id FROM users WHERE id!=? AND banned=0",(uid,))]; conn.close()

    resolved=[]
    for token in tokens:
        skill=next((x for x in SKILLS if x.casefold()==token),None)
        skill=skill or next((x for x in SKILLS if token and token in x.casefold()),None)
        interest=next((x for x in INTERESTS if x.casefold()==token),None)
        interest=interest or next((x for x in INTERESTS if token and token in x.casefold()),None)
        resolved.append((token,skill,interest))

    out=[]
    for oid in ids:
        u,s,i=user_data(oid); names=set(s); union=my_names|names; complement=my_names^names
        interest=len(my_interests&i)/max(len(my_interests),1)*100
        complement_score=len(complement)/max(len(union),1)*100
        other_av={x.strip() for x in (u["availability"] or "").split(",") if x.strip()}
        availability=len(my_av&other_av)/max(len(my_av),1)*100
        overlap=len(my_names&names)/max(len(my_names),1)*100
        my_state=(me["state"] or "").strip().casefold()
        other_state=(u["state"] or "").strip().casefold()
        same_state=bool(my_state and other_state and my_state==other_state)
        same_district=bool(same_state and (me["district"] or "").strip().casefold() and (me["district"] or "").strip().casefold()==(u["district"] or "").strip().casefold())
        total=.40*complement_score+.25*interest+.20*availability+.15*overlap

        matched_count=0; rating_sum=0.0; rating_count=0; generic_match=False
        for token,skill,interest_name in resolved:
            if skill:
                if skill in s:
                    matched_count += 1
                    rating_sum += s.get(skill,0)
                    rating_count += 1
            elif interest_name:
                if interest_name in i:
                    matched_count += 1
                    rating_sum += 1
                    rating_count += 1
            elif token:
                haystack=" ".join([u["name"],u["branch"],u["state"] or "",u["district"] or "",*s.keys(),*i]).casefold()
                if token in haystack:
                    matched_count += 1
                    generic_match=True
                    rating_sum += 1
                    rating_count += 1

        attribute_coverage=(matched_count/len(resolved)*100) if resolved else 0.0
        attribute_rating=(rating_sum/rating_count) if rating_count else 0.0
        experience_rating, experience_count, _ = get_experience_summary(oid)
        out.append({"user":u,"skills":s,"interests":i,"score":round(total,1),
                    "attribute_rating":round(attribute_rating,2),"attribute_match":matched_count>0,
                    "attribute_coverage":round(attribute_coverage,1),"matched_count":matched_count,
                    "search_count":len(resolved),"generic_match":generic_match,
                    "experience_rating":experience_rating,"experience_count":experience_count,
                    "same_state":same_state,"same_district":same_district})

    if tokens:
        # Multiple-attribute search is an AND-style preference: people matching
        # more of the requested attributes rank first. A candidate does not have
        # to match every term, so useful partial matches remain visible.
        out=[x for x in out if x["attribute_match"]]
        # Location priority: students in the same state always come first.
        # Within the same state, matching more requested attributes is preferred;
        # then skill/attribute rating, district proximity, experience and compatibility.
        out.sort(key=lambda x:(x["same_state"], x["attribute_coverage"], x["attribute_rating"], x["same_district"], x["experience_rating"] or 0, x["score"]), reverse=True)
    else:
        # For general recommendations, same-state students are always ranked above
        # students from other states, followed by district/location, compatibility and experience.
        out.sort(key=lambda x:(x["same_state"], x["same_district"], x["score"], x["experience_rating"] or 0), reverse=True)
    return out[:limit]

def page(title,body,**ctx): return render_template_string(LAYOUT,title=title,body=render_template_string(body,**ctx))

def profile_form(u=None,skills=None,interests=None):
    selected_state=LOCATION_ALIASES.get((u["state"] if u else ""),(u["state"] if u else ""))
    selected_district=u["district"] if u else ""
    return render_template_string(PROFILE_FORM,u=u,skills=skills or {},interests=interests or set(),all_skills=SKILLS,all_interests=INTERESTS,availability=AVAILABILITY,location_data=LOCATION_DATA,selected_state=selected_state,selected_district=selected_district,work_styles=WORK_STYLES,commitments=COMMITMENTS,goals=GOALS,communications=COMMUNICATIONS)


PROFILE_FORM='''<form method="post"><div class="form-grid">
<div><label>Full name</label><input name="name" value="{{u.name if u else ''}}" required></div><div><label>Email</label><input type="email" name="email" value="{{u.email if u else ''}}" required></div>
<div><label>Phone / WhatsApp</label><input name="phone" value="{{u.phone if u else ''}}"></div><div><label>Branch</label><input name="branch" value="{{u.branch if u else ''}}" required></div>
<div><label>Year</label><select name="year">{% for y in range(1,5) %}<option value="{{y}}" {% if u and u.year==y %}selected{% endif %}>Year {{y}}</option>{% endfor %}</select></div>{% if not u %}<div><label>Password</label><input type="password" name="password" minlength="6" required></div>{% endif %}
<div><label>Working style</label><select name="work_style"><option value="">Choose</option>{% for v,l in work_styles %}<option value="{{v}}" {% if u and u.work_style==v %}selected{% endif %}>{{l}}</option>{% endfor %}</select></div>
<div><label>Commitment</label><select name="commitment"><option value="">Choose</option>{% for v,l in commitments %}<option value="{{v}}" {% if u and u.commitment==v %}selected{% endif %}>{{l}}</option>{% endfor %}</select></div>
<div><label>Goal</label><select name="goal"><option value="">Choose</option>{% for v,l in goals %}<option value="{{v}}" {% if u and u.goal==v %}selected{% endif %}>{{l}}</option>{% endfor %}</select></div>
<div><label>Communication</label><select name="communication"><option value="">Choose</option>{% for v,l in communications %}<option value="{{v}}" {% if u and u.communication==v %}selected{% endif %}>{{l}}</option>{% endfor %}</select></div>
<div><label>Working start hour (0–23)</label><input type="number" name="working_start" min="0" max="23" value="{{u.working_start if u and u.working_start is not none else ''}}"></div>
<div><label>Working end hour (0–24)</label><input type="number" name="working_end" min="0" max="24" value="{{u.working_end if u and u.working_end is not none else ''}}"></div></div>
<div class="form-grid"><div><label>State / Union Territory</label><select name="state" id="stateSelect" required><option value="">Select your state</option>{% for state in location_data.keys()|sort %}<option value="{{state}}" {% if state==selected_state %}selected{% endif %}>{{state}}</option>{% endfor %}</select></div><div><label>District</label><select name="district" id="districtSelect" required><option value="">Select your district</option></select></div></div>
<label>About You (max 50 words)</label><textarea name="bio" maxlength="350">{{u.bio if u and u.bio else ''}}</textarea>
<label>Availability</label><div class="check-grid">{% for value,label in availability %}<label class="check"><input type="checkbox" name="availability" value="{{value}}" {% if u and value in (u.availability or '').split(',') %}checked{% endif %}> {{label}}</label>{% endfor %}</div>
<h3>Skills <span class="small">(0 = none, 5 = expert)</span></h3>{% for sk in all_skills %}<div class="skill-row"><label>{{sk}}</label><select name="skill_{{sk}}"><option value="0">0</option>{% for n in range(1,6) %}<option value="{{n}}" {% if skills.get(sk,0)==n %}selected{% endif %}>{{n}} / 5</option>{% endfor %}</select></div>{% endfor %}
<h3>Interests</h3><div class="check-grid">{% for i in all_interests %}<label class="check"><input type="checkbox" name="interests" value="{{i}}" {% if i in interests %}checked{% endif %}> {{i}}</label>{% endfor %}</div><button class="btn">{{'Save Changes' if u else 'Create Student Account'}}</button></form>
<script>(function(){const data={{location_data|tojson}},state=document.getElementById('stateSelect'),district=document.getElementById('districtSelect'),selected={{selected_district|tojson}};function fill(use){district.innerHTML='<option value="">Select your district</option>';(data[state.value]||[]).forEach(n=>{const o=document.createElement('option');o.value=n;o.textContent=n;if(use&&n===selected)o.selected=true;district.appendChild(o)})}state.addEventListener('change',()=>fill(false));fill(true)})();</script>'''

@app.route('/')
def home():
    return page('Home','''<section class="hero"><div class="eyebrow">Student collaboration platform</div><h1>Find the right people for your next big project.</h1><p>Build your student profile, discover complementary teammates and match with campus projects using skills, interests and availability.</p><div class="actions">{% if session.get('user_id') %}<a class="btn" href="/find-teammate">Find teammates</a><a class="btn ghost" href="/projects">Explore projects</a>{% else %}<a class="btn" href="/register">Create your profile</a><a class="btn ghost" href="/login">Sign in</a>{% endif %}</div></section><div class="grid"><div class="card"><h3>🤝 Smart teammate matching</h3><p class="muted">Recommendations prioritize complementary skills, shared interests and schedule overlap.</p></div><div class="card"><h3>📊 Project matching</h3><p class="muted">See which projects fit your current skills and interests.</p></div><div class="card"><h3>⭐ Team experience ratings</h3><p class="muted">Learn how students performed in previous collaborations through ratings and feedback.</p></div><div class="card"><h3>🔒 Follow to connect</h3><p class="muted">Follow a teammate to unlock their contact details and connect outside the platform.</p></div></div>''')

def preference_values(form):
    return (form.get("work_style",""),form.get("commitment",""),form.get("goal",""),form.get("communication",""),
            safe_int(form.get("working_start"),None,0,23) if form.get("working_start","")!="" else None,
            safe_int(form.get("working_end"),None,0,24) if form.get("working_end","")!="" else None)

@app.route('/register',methods=['GET','POST'])
def register():
    if request.method=='POST':
        name=request.form['name'].strip(); email=request.form['email'].strip().lower(); password=request.form['password']; phone=request.form.get('phone','').strip(); branch=request.form['branch'].strip(); year=int(request.form['year']); availability=','.join(request.form.getlist('availability')); state=request.form.get('state','').strip(); district=request.form.get('district','').strip(); bio=request.form.get('bio','').strip()
        if state not in LOCATION_DATA or district not in LOCATION_DATA.get(state, []):
            flash('Please select a valid state and district.','error')
            return page('Register','<div class="two"><div class="card"><h2>Create your student profile</h2><p class="muted">The more complete your profile, the better the matches.</p>{{form|safe}}</div><div class="card"><h3>What you get</h3><p>✓ Ranked teammate recommendations</p><p>✓ Project compatibility scores</p><p>✓ Skills & interest profile</p><p>✓ Contact details for collaboration</p></div></div>',form=profile_form())
        if len(bio.split()) > 50:
            flash('About You must be 50 words or fewer.','error')
            return page('Register','<div class="two"><div class="card"><h2>Create your student profile</h2><p class="muted">The more complete your profile, the better the matches.</p>{{form|safe}}</div><div class="card"><h3>What you get</h3><p>✓ Ranked teammate recommendations</p><p>✓ Project compatibility scores</p><p>✓ Skills & interest profile</p><p>✓ Contact details for collaboration</p></div></div>',form=profile_form())
        conn=db()
        try:
            cur=conn.execute('INSERT INTO users(name,email,password,phone,branch,year,availability,bio,location,state,district,latitude,longitude) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',(name,email,generate_password_hash(password),phone,branch,year,availability,request.form.get('bio','').strip()[:350],None,state,district,None,None)); uid=cur.lastrowid
            save_profile_rows(conn,uid,request.form); ws,cm,go,co,st,en=preference_values(request.form); conn.execute("UPDATE users SET work_style=?,commitment=?,goal=?,communication=?,working_start=?,working_end=? WHERE id=?",(ws,cm,go,co,st,en,uid)); conn.commit(); session['user_id']=uid; flash('Welcome! Your student profile is ready.','success'); return redirect(url_for('dashboard'))
        except sqlite3.IntegrityError: conn.rollback(); flash('That email is already registered. Please log in instead.','error')
        finally: conn.close()
    return page('Register','<div class="two"><div class="card"><h2>Create your student profile</h2><p class="muted">The more complete your profile, the better the matches.</p>{{form|safe}}</div><div class="card"><h3>What you get</h3><p>✓ Ranked teammate recommendations</p><p>✓ Project compatibility scores</p><p>✓ Skills & interest profile</p><p>✓ Contact details for collaboration</p></div></div>',form=profile_form())

def save_profile_rows(conn,uid,form):
    for s in SKILLS:
        level=int(form.get('skill_'+s,0) or 0)
        if level: conn.execute('INSERT OR REPLACE INTO skills(user_id,skill,level) VALUES(?,?,?)',(uid,s,level))
        else: conn.execute('DELETE FROM skills WHERE user_id=? AND skill=?',(uid,s))
    conn.execute('DELETE FROM interests WHERE user_id=?',(uid,))
    for i in form.getlist('interests'):
        if i in INTERESTS: conn.execute('INSERT OR IGNORE INTO interests(user_id,interest) VALUES(?,?)',(uid,i))

@app.route('/login',methods=['GET','POST'])
def login():
    if request.method=='POST':
        email=request.form['email'].strip().lower(); password=request.form['password']; conn=db(); u=conn.execute('SELECT * FROM users WHERE email=? AND banned=0',(email,)).fetchone(); conn.close()
        valid=False
        if u:
            try: valid=check_password_hash(u['password'],password)
            except ValueError: valid=(u['password']==password) # migrate legacy demo accounts on successful login
        if valid:
            if u['password']==password: migrate_password(u['id'],password)
            session.clear(); session['user_id']=u['id']; return redirect(url_for('dashboard'))
        flash('Invalid email or password.','error')
    return page('Login','''<div class="card" style="max-width:520px;margin:35px auto"><h2>Welcome back</h2><p class="muted">Sign in to access your teammate and project matches.</p><form method="post"><label>Email</label><input type="email" name="email" required><label>Password</label><input type="password" name="password" required><button class="btn">Sign in</button></form><div class="divider"></div><p class="small">New here? <a href="/register">Create an account</a></p></div>''')

def migrate_password(uid,password):
    conn=db(); conn.execute('UPDATE users SET password=? WHERE id=?',(generate_password_hash(password),uid)); conn.commit(); conn.close()

@app.route('/logout')
def logout(): session.clear(); return redirect(url_for('home'))

@app.route('/dashboard')
@login_required
def dashboard():
    u,skills,interests=user_data(session['user_id']); conn=db(); student_count=conn.execute('SELECT COUNT(*) FROM users').fetchone()[0]; project_count=conn.execute('SELECT COUNT(*) FROM projects').fetchone()[0]; conn.close()
    return page('Dashboard','''<div class="row"><div><div class="eyebrow">Dashboard</div><h1>Hi, {{u.name.split()[0]}} 👋</h1><p class="muted">Here’s your collaboration overview.</p></div><a class="btn" href="/find-teammate">Find teammates</a></div><div class="grid"><div class="stat"><span class="small">Students</span><b>{{student_count}}</b></div><div class="stat"><span class="small">Projects</span><b>{{project_count}}</b></div><div class="stat"><span class="small">Your skills</span><b>{{skills|length}}</b></div><div class="stat"><span class="small">Interests</span><b>{{interests|length}}</b></div></div><div class="two" style="margin-top:20px"><div class="card"><h2>Your profile</h2><p><b>{{u.branch}}</b> · Year {{u.year}}</p><p class="muted">{{u.email}}{% if u.phone %} · {{u.phone}}{% endif %}</p>{% for k,v in skills.items() %}<span class="badge">{{k}} {{v}}/5</span>{% endfor %}<div class="actions"><a class="btn secondary" href="/profile">Edit profile</a><a class="btn" href="/projects">Explore projects</a></div></div><div class="card"><h2>Quick start</h2><p>1. Complete your skills and interests.</p><p>2. Find teammates with complementary strengths.</p><p>3. Explore projects and build a team.</p></div></div>''',u=u,skills=skills,interests=interests,student_count=student_count,project_count=project_count)

@app.route('/profile',methods=['GET','POST'])
@login_required
def profile():
    uid=session['user_id']; u,skills,interests=user_data(uid)
    if request.method=='POST':
        name=request.form.get('name','').strip(); email=request.form.get('email','').strip().lower(); phone=request.form.get('phone','').strip(); branch=request.form.get('branch','').strip(); year=safe_int(request.form.get('year'),1,1,4); state=request.form.get('state','').strip(); district=request.form.get('district','').strip(); bio=request.form.get('bio','').strip()
        if not name or not email or not branch: flash('Name, email and branch are required.','error')
        elif state not in LOCATION_DATA or district not in LOCATION_DATA.get(state,[]): flash('Please select a valid state and district.','error')
        elif len(bio.split())>50: flash('About You must be 50 words or fewer.','error')
        else:
            conn=db()
            try:
                ws,cm,go,co,st,en=preference_values(request.form)
                conn.execute('UPDATE users SET name=?,email=?,phone=?,branch=?,year=?,availability=?,bio=?,state=?,district=?,work_style=?,commitment=?,goal=?,communication=?,working_start=?,working_end=? WHERE id=?',
                    (name,email,phone,branch,year,','.join(request.form.getlist('availability')),bio[:350],state,district,ws,cm,go,co,st,en,uid))
                save_profile_rows(conn,uid,request.form); conn.commit(); flash('Profile updated successfully.','success'); return redirect(url_for('profile'))
            except sqlite3.IntegrityError: conn.rollback(); flash('That email is already in use.','error')
            finally: conn.close()
            u,skills,interests=user_data(uid)
    return page('My Profile','<div class="card"><div class="row"><div><div class="eyebrow">Profile</div><h1>My profile</h1></div><a class="btn secondary" href="/find-teammate">View matches</a></div>{{form|safe}}</div>',form=profile_form(u,skills,interests))


@app.route('/skill-tree')
@login_required
def skill_tree():
    _,skills,_=user_data(session['user_id'])
    groups=[('Software Development',['React','JavaScript','Python','SQL','Machine Learning']),
            ('Hardware',['Embedded Systems','IoT','Arduino','Robotics']),
            ('Design & Engineering',['UI/UX','CAD']),
            ('Data',['Data Analysis','SQL','Machine Learning'])]
    return page('Skill Tree','''<div class="card"><div class="eyebrow">Skill visualization</div><h1>Your skill tree</h1><p class="muted">Strength is calculated directly from your saved skill levels.</p><div class="skill-tree">{% for title,items in groups %}<div class="card"><h3>{{title}}</h3>{% for sk in items %}{% set v=skills.get(sk,0) %}<div class="skill-line"><div class="row"><span>{{sk}}</span><b>{{v}}/5</b></div><div class="mini-bar"><i style="width:{{v*20}}%"></i></div></div>{% endfor %}</div>{% endfor %}</div></div>''',skills=skills,groups=groups)

@app.route('/find-teammate',methods=['GET','POST'])
@login_required
def find_teammate():
    uid=session['user_id']
    # Always initialize the search text. A normal GET request has no form
    # payload, so referencing a POST-only local variable caused an
    # UnboundLocalError on /find-teammate.
    text=request.values.get('search_text','').strip()
    conn=db()
    if request.method=='POST' and text:
        conn.execute('INSERT INTO teammate_queries(user_id,search_text) VALUES(?,?)',(uid,text))
        conn.commit()
        flash('Search saved. Matching students are ranked by the searched attribute.','success')
    queries=conn.execute('SELECT * FROM teammate_queries WHERE user_id=? ORDER BY id DESC',(uid,)).fetchall()
    conn.close()
    results=find_teammates(uid, text)
    return page('Find Teammates','''<div class="row"><div><div class="eyebrow">Team formation</div><h1>Find your teammates</h1><p class="muted">Recommendations prioritize students in your state first, then use skills, interests, availability and state/district.</p></div><a class="btn secondary" href="/profile">Improve my profile</a></div><div class="card"><form method="get"><label>Search for one or more attributes</label><input name="search_text" value="{{search_text}}" placeholder="e.g. CAD, Python, Robotics"><p class="small">Use commas to search multiple attributes. Example: <b>CAD, Python, Robotics</b>. People matching more of your requested attributes rank higher.</p><button class="btn" type="submit">Search teammates</button>{% if search_text %}<a class="btn secondary" href="/find-teammate">Clear</a>{% endif %}</form><p class="small">For a single skill such as <b>CAD</b>, students from your state are shown first, then ranked by CAD rating. For multiple attributes such as <b>CAD, Python, Robotics</b>, same-state students are prioritized first, then students matching more requested attributes; skill ratings, district, team experience and compatibility refine the order.</p></div><h2>Recommended students</h2>{% for r in results %}<div class="card"><div class="row"><div><h3>#{{loop.index}} {{r.user.name}}</h3><p class="muted">{{r.user.branch}} · Year {{r.user.year}}{% if r.user.district %}, {{r.user.district}}{% endif %}{% if r.user.state %}, {{r.user.state}}{% endif %}</p></div><div style="min-width:160px"><div class="score">{{r.score}}%</div><div class="scorebar"><i style="width:{{r.score}}%"></i></div></div></div><div><b>Skills</b><br>{% for k,v in r.skills.items() %}<span class="badge">{{k}} {{v}}/5</span>{% endfor %}</div>{% if r.experience_rating %}<p class="rating"><span class="stars">★★★★★</span> {{r.experience_rating}}/5 <span class="muted">({{r.experience_count}} team experience{{'' if r.experience_count==1 else 's'}})</span></p>{% else %}<p class="small">No team experience ratings yet</p>{% endif %}<p><b>Interests:</b> {{r.interests|join(', ') if r.interests else 'Not specified'}}</p><p><b>Availability:</b> {{r.user.availability or 'Not specified'}}</p><a class="btn" href="/teammate/{{r.user.id}}">View profile & follow</a></div>{% else %}<div class="card empty">No other students are registered yet. Add another student account to test matching.</div>{% endfor %}<div class="card"><h3>Saved search notes</h3>{% for q in queries %}<div class="row" style="padding:10px 0;border-bottom:1px solid var(--border)"><span>{{q.search_text}} <span class="small">· {{q.created_at}}</span></span><form method="post" action="/delete-query/{{q.id}}"><button class="btn danger" type="submit">Delete</button></form></div>{% else %}<p class="small">No saved notes.</p>{% endfor %}</div>''',results=results,queries=queries,search_text=text)

@app.route('/delete-query/<int:qid>',methods=['POST'])
@login_required
def delete_query(qid):
    conn=db(); conn.execute('DELETE FROM teammate_queries WHERE id=? AND user_id=?',(qid,session['user_id'])); conn.commit(); conn.close(); flash('Search note deleted.','success'); return redirect(url_for('find_teammate'))

@app.route('/rate-teammate/<int:uid>',methods=['GET','POST'])
@login_required
def rate_teammate(uid):
    reviewer_id=session['user_id']
    if uid==reviewer_id:
        flash('You cannot rate yourself.','error'); return redirect(url_for('profile'))
    reviewed,_,_=user_data(uid)
    if not reviewed: abort(404)
    if request.method=='POST':
        experience=request.form.get('experience','').strip()
        comment=request.form.get('comment','').strip()
        try: rating=int(request.form.get('rating','0'))
        except ValueError: rating=0
        if not experience or len(experience)<3:
            flash('Please enter the hackathon, project or event you worked on together.','error')
        elif rating not in range(1,6):
            flash('Please choose a rating from 1 to 5.','error')
        else:
            conn=db()
            try:
                conn.execute('INSERT INTO experience_ratings(reviewer_id,reviewed_id,experience,rating,comment) VALUES(?,?,?,?,?)',(reviewer_id,uid,experience,rating,comment[:500]))
                conn.commit(); flash('Your teammate experience rating was submitted.','success'); return redirect(url_for('teammate',uid=uid))
            except sqlite3.IntegrityError:
                conn.rollback(); flash('You have already rated this teammate for that experience. Use a different project or hackathon.','error')
            finally: conn.close()
    avg,count,recent=get_experience_summary(uid)
    body="""<div class="card" style="max-width:700px;margin:auto"><a href="/teammate/{{u.id}}">← Back to {{u.name}}</a><div class="eyebrow" style="margin-top:20px">Post-project feedback</div><h1>Rate {{u.name}}</h1><p class="muted">Only rate someone you have genuinely worked with. Your feedback helps other students choose reliable teammates.</p><form method="post"><label>Hackathon / project / event</label><input name="experience" required maxlength="120" placeholder="e.g. Smart India Hackathon 2026"><label>How well did they perform?</label><div class="check-grid" style="grid-template-columns:repeat(5,1fr)">{% for n in range(1,6) %}<label class="check" style="justify-content:center"><input type="radio" name="rating" value="{{n}}" required> {{n}} ★</label>{% endfor %}</div><label>Comments <span class="small">(optional)</span></label><textarea name="comment" maxlength="500" placeholder="What did they do well? Were they reliable, collaborative and effective?"></textarea><button class="btn" type="submit">Submit experience rating</button></form>{% if avg %}<div class="divider"></div><p class="rating"><span class="stars">★★★★★</span> {{avg}} / 5 · {{count}} experience rating{{'' if count==1 else 's'}}</p>{% endif %}</div>"""
    return page('Rate Teammate',body,u=reviewed,avg=avg,count=count,recent=recent)


@app.route('/report-user/<int:uid>',methods=['POST'])
@login_required
def report_user(uid):
    if uid==session['user_id']: return redirect(url_for('teammate',uid=uid))
    conn=db()
    conn.execute('INSERT OR IGNORE INTO user_reports(reporter_id,reported_id) VALUES(?,?)',(session['user_id'],uid))
    count=conn.execute('SELECT COUNT(*) FROM user_reports WHERE reported_id=?',(uid,)).fetchone()[0]
    if count>=5:
        conn.execute('UPDATE users SET banned=1 WHERE id=?',(uid,))
    conn.commit(); conn.close(); flash('User reported.','success'); return redirect(url_for('teammate',uid=uid))

@app.route('/follow/<int:uid>', methods=['POST'])
@login_required
def follow_user(uid):
    follower_id=session['user_id']
    if uid==follower_id:
        flash('You cannot follow yourself.','error')
        return redirect(url_for('profile'))
    conn=db(); target=conn.execute('SELECT id,name,banned FROM users WHERE id=?',(uid,)).fetchone()
    if not target or target['banned']:
        conn.close(); abort(404)
    try:
        conn.execute('INSERT INTO follows(follower_id,following_id) VALUES(?,?)',(follower_id,uid))
        conn.commit(); flash(f'You are now following {target["name"]}. Contact details are unlocked.','success')
    except sqlite3.IntegrityError:
        conn.rollback(); flash('You already follow this student.','success')
    finally:
        conn.close()
    return redirect(url_for('teammate',uid=uid))

@app.route('/unfollow/<int:uid>', methods=['POST'])
@login_required
def unfollow_user(uid):
    if uid==session['user_id']:
        return redirect(url_for('profile'))
    conn=db(); conn.execute('DELETE FROM follows WHERE follower_id=? AND following_id=?',(session['user_id'],uid)); conn.commit(); conn.close()
    flash('You unfollowed this student. Their contact details are locked again.','success')
    return redirect(url_for('teammate',uid=uid))

@app.route('/teammate/<int:uid>')
@login_required
def teammate(uid):
    if uid==session['user_id']: return redirect(url_for('profile'))
    u,skills,interests=user_data(uid)
    if not u: abort(404)
    matches=find_teammates(session['user_id'],limit=100); match=next((x for x in matches if x['user']['id']==uid),None)
    score=match['score'] if match else None
    avg,count,recent=get_experience_summary(uid)
    conn=db(); following=conn.execute('SELECT 1 FROM follows WHERE follower_id=? AND following_id=?',(session['user_id'],uid)).fetchone() is not None; conn.close()
    body="""<div class="card"><a href="/find-teammate">← Back to recommendations</a><div class="row" style="margin-top:20px"><div><div class="eyebrow">Student profile</div><h1>{{u.name}}</h1><p class="muted">{{u.branch}} · Year {{u.year}}{% if u.district %}, {{u.district}}{% endif %}{% if u.state %}, {{u.state}}{% endif %}</p>{% if avg %}<p class="rating"><span class="stars">★★★★★</span> {{avg}}/5 <span class="muted">({{count}} experience{{'' if count==1 else 's'}})</span></p>{% else %}<p class="muted">No teammate experience ratings yet</p>{% endif %}</div>{% if score is not none %}<div><div class="score">{{score}}% match</div><div class="scorebar"><i style="width:{{score}}%"></i></div></div>{% endif %}</div><div class="divider"></div><div class='actions'><a class='btn' href='/rate-teammate/{{u.id}}'>⭐ Rate this teammate</a><form method='post' action='/report-user/{{u.id}}' style='display:inline'><button class='btn danger' type='submit'>Report Imposter</button></form></div><p class="small">Worked with {{u.name}} at a hackathon or project? Share your experience to help future teams make better choices.</p><div class="divider"></div><h3>Contact details</h3>{% if following %}<div class="notice success">✓ You follow {{u.name}}. Their contact details are unlocked.</div><p>📧 <a href="mailto:{{u.email}}">{{u.email}}</a></p><p>📱 {% if u.phone %}<a href="tel:{{u.phone}}">{{u.phone}}</a>{% else %}Not provided{% endif %}</p><form method="post" action="/unfollow/{{u.id}}"><button class="btn secondary" type="submit">Unfollow {{u.name}}</button></form>{% else %}<div class="notice" class="notice info">🔒 Follow {{u.name}} to unlock their contact details. You can still view their skills, interests and team experience.</div><form method="post" action="/follow/{{u.id}}"><button class="btn" type="submit">+ Follow {{u.name}}</button></form>{% endif %}<h3>Skills</h3>{% for k,v in skills.items() %}<span class="badge">{{k}} {{v}}/5</span>{% else %}<p class="muted">No skills listed.</p>{% endfor %}<h3>Interests</h3><p>{{interests|join(', ') if interests else 'Not specified'}}</p><h3>About</h3><p>{{u.bio or 'No description provided.'}}</p><h3>Availability</h3><p>{{u.availability or 'Not specified'}}</p></div>{% if recent %}<div class="card rating-card"><div class="row"><h2>Team experience</h2><span class="small">{{count}} community rating{{'' if count==1 else 's'}}</span></div>{% for r in recent %}<div class="rating-item"><div class="row"><b>{{r.experience}}</b><span class="rating"><span class="stars">{{'★' * r.rating}}{{'☆' * (5-r.rating)}}</span> {{r.rating}}/5</span></div>{% if r.comment %}<p>{{r.comment}}</p>{% endif %}<p class="small">Shared by {{r.reviewer_name}} · {{r.created_at}}</p></div>{% endfor %}</div>{% endif %}"""
    return page('Teammate Profile',body,u=u,skills=skills,interests=interests,score=score,avg=avg,count=count,recent=recent,following=following)

@app.route('/projects')
@login_required
def projects_page():
    conn=db(); ps=conn.execute('SELECT p.*,u.name AS owner_name FROM projects p LEFT JOIN users u ON p.owner_id=u.id ORDER BY p.id DESC').fetchall(); conn.close(); cards=[]
    for p in ps:
        req,pref,ints,av=parse_project(p); cards.append((p,score_student(session['user_id'],req,ints,av,p)))
    cards.sort(key=lambda x:x[1],reverse=True)
    return page('Projects','''<div class="row"><div><div class="eyebrow">Discover</div><h1>Project marketplace</h1><p class="muted">Projects ranked by your skills, interests and availability.</p></div><a class="btn" href="/add-project">+ Create project</a></div>{% for p,score in cards %}<div class="card"><div class="row"><div><h2>{{p.title}}</h2><p>{{p.description}}</p><p class="small">{% if p.owner_name %}Created by {{p.owner_name}} · {% endif %}Team size {{p.team_size}}</p></div><div style="min-width:160px"><div class="score">{{score}}%</div><div class="scorebar"><i style="width:{{score}}%"></i></div></div></div><p><b>Required skills:</b> {{p.required_skills or 'Flexible'}}</p><p><b>Interests:</b> {{p.interests or 'Any'}}</p><a class="btn" href="/project/{{p.id}}">View team suggestions</a></div>{% endfor %}''',cards=cards)

@app.route('/project/<int:pid>')
@login_required
def project(pid):
    conn=db(); p=conn.execute('SELECT p.*,u.name AS owner_name FROM projects p LEFT JOIN users u ON p.owner_id=u.id WHERE p.id=?',(pid,)).fetchone()
    if not p: conn.close(); abort(404)
    members=conn.execute('SELECT pm.*,u.name,u.branch,u.year,u.working_start,u.working_end FROM project_members pm JOIN users u ON u.id=pm.user_id WHERE pm.project_id=?',(pid,)).fetchall()
    ids=[m['user_id'] for m in members]; conn.close()
    if not ids and p['owner_id']: ids=[p['owner_id']]
    a=team_analysis(pid); dna=project_dna(p)
    req,_,_,_=parse_project(p)
    conn=db(); candidates=[r['id'] for r in conn.execute('SELECT id FROM users WHERE id!=? AND banned=0',(session['user_id'],)).fetchall()]; conn.close()
    ranked=[]
    for uid in candidates:
        if uid not in ids:
            c=project_compatibility(uid,pid)
            if c: ranked.append((uid,c))
    ranked.sort(key=lambda x:x[1]['overall'],reverse=True)
    people=[(user_data(uid)[0],c) for uid,c in ranked[:max(5,p['team_size'] or 3)]]
    common=[]
    for h in range(24):
        if ids and all((user_data(i)[0]['working_start'] is not None and user_data(i)[0]['working_end'] is not None and user_data(i)[0]['working_start']<=h<user_data(i)[0]['working_end']) for i in ids): common.append(h)
    return page('Project Team','''<div class="card"><a href="/projects">← Back to projects</a><div class="eyebrow" style="margin-top:20px">Project</div><h1>{{p.title}}</h1><p>{{p.description}}</p><p><b>Problem:</b> {{p.problem or 'Not specified'}}</p><p><b>Objective:</b> {{p.objective or 'Not specified'}}</p><div class="pill-row"><span class="badge">{{p.personality or 'Open team'}}</span><span class="badge">{{p.goal or 'Goal not set'}}</span><span class="badge">{{p.commitment or 'Commitment not set'}}</span></div></div>
<div class="card"><h2>Project DNA</h2><div class="dna-grid">{% for label,val in [('Difficulty',dna.difficulty),('Time commitment',dna.time),('Collaboration',dna.collaboration),('Deadline pressure',dna.pressure)] %}<div class="dna"><span>{{label}}</span><br><b>{{val}}/10</b><div class="scorebar"><i style="width:{{val*10}}%"></i></div></div>{% endfor %}</div><p class="small">Derived from the saved brief: skills, hours, duration, team size/roles, pace and deadline.</p></div>
<div class="two"><div class="card"><h2>Team weakness / skill gaps</h2>{% for g in analysis.gaps %}<div class="meter"><span>{{g.skill}}</span><div class="meter-track"><i style="width:{{[100,(g.have/g.required*100 if g.required else 100)]|min}}%"></i></div><b class="{{'gap-good' if g.status=='Strong' else ('gap-warn' if g.status=='Weak' else 'gap-bad')}}">{{g.status}}</b></div>{% else %}<p class="muted">No requirements entered.</p>{% endfor %}<p class="tip">Adding or removing members changes this analysis because it is calculated from current team data.</p></div>
<div class="card"><h2>Availability</h2>{% if common %}<p>⭐ Best common working hours: {% for h in common %}{{h}}:00{% if not loop.last %}, {% endif %}{% endfor %}</p>{% else %}<p class="muted">No single common hour is available from the saved member schedules.</p>{% endif %}{% for m in members %}<div class="overlap"><span>{{m.name}}</span><div class="timeline">{% if m.working_start is not none and m.working_end is not none %}<i style="left:{{m.working_start/24*100}}%;width:{{[(m.working_end-m.working_start)/24*100,2]|max}}%"></i>{% endif %}</div></div>{% endfor %}</div></div>
<div class="card"><h2>Recommended candidates</h2><p class="muted">The algorithm rewards complementary skills and explains the recommendation.</p>{% for u,c in people %}<div class="card"><div class="row"><div><h3>{{u.name}}</h3><p class="muted">{{u.branch}} · Year {{u.year}}</p></div><div class="score">{{c.overall}}% Team Fit</div></div><div class="chem-grid">{% for label,val in [('Technical fit',c.technical),('Complementary skills',c.complementary),('Work style',c.work),('Communication',c.communication),('Time compatibility',c.time),('Goal alignment',c.goal),('Commitment',c.commitment)] %}<div class="chem"><b>{{label}}</b><div class="scorebar"><i style="width:{{val}}%"></i></div><span>{{val}}%</span></div>{% endfor %}</div><p><b>Why recommended:</b> {{c.reasons|join(' · ')}}</p><a class="btn" href="/teammate/{{u.id}}">View candidate</a><form method="post" action="/join-project/{{p.id}}" style="display:inline"><input type="hidden" name="role" value="Contributor"><button class="btn secondary">Add to team</button></form></div>{% else %}<div class="empty">No candidates available.</div>{% endfor %}</div>
<div class="card"><h2>Current team</h2>{% for m in members %}<div class="row" style="padding:10px 0;border-bottom:1px solid var(--border)"><span><b>{{m.name}}</b> · {{m.role or 'Contributor'}}</span>{% if m.user_id==session.get('user_id') and m.user_id!=p.owner_id %}<form method="post" action="/leave-project/{{p.id}}"><button class="btn danger">Leave</button></form>{% endif %}</div>{% else %}<p class="muted">No members yet.</p>{% endfor %}</div>''',p=p,dna=dna,analysis=a,people=people,members=members,common=common)


@app.route('/add-project',methods=['GET','POST'])
@login_required
def add_project():
    if request.method=='POST':
        title=request.form.get('title','').strip(); description=request.form.get('description','').strip(); problem=request.form.get('problem','').strip(); objective=request.form.get('objective','').strip()
        if not title or not description or not problem or not objective:
            flash('Complete the project name, description, problem and objective.','error'); return redirect(url_for('add_project'))
        team_size=safe_int(request.form.get('team_size'),3,1,10); req=[]; pref=[]
        for sk in SKILLS:
            r=safe_int(request.form.get('req_'+sk),0,0,5); pr=safe_int(request.form.get('pref_'+sk),0,0,5)
            if r: req.append(f'{sk}:{r}')
            if pr: pref.append(f'{sk}:{pr}')
        interests=','.join(i for i in request.form.getlist('interests') if i in INTERESTS)
        av=','.join(a for a,_ in AVAILABILITY if a in request.form.getlist('availability'))
        roles=[]
        for n in range(1,6):
            role=request.form.get(f'role_{n}','').strip(); resp=request.form.get(f'resp_{n}','').strip()
            if role: roles.append(role+'|'+resp+'|1')
        conn=db()
        cur=conn.execute('''INSERT INTO projects(owner_id,title,description,required_skills,preferred_skills,interests,availability,team_size,problem,objective,open_roles,time_hours,duration_weeks,deadline,work_pace,work_structure,communication,goal,commitment,personality)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',(session['user_id'],title,description,','.join(req),','.join(pref),interests,av,team_size,problem,objective,';'.join(roles),safe_int(request.form.get('time_hours'),8,1,80),safe_int(request.form.get('duration_weeks'),8,1,52),request.form.get('deadline',''),request.form.get('work_pace','relaxed'),request.form.get('work_structure','flexible'),request.form.get('communication','mixed'),request.form.get('goal','academic'),request.form.get('commitment','moderate'),request.form.get('personality','')))
        pid=cur.lastrowid; p=conn.execute('SELECT * FROM projects WHERE id=?',(pid,)).fetchone(); dna=project_dna(p)
        conn.execute('UPDATE projects SET dna_difficulty=?,dna_time=?,dna_collaboration=?,dna_pressure=? WHERE id=?',(dna['difficulty'],dna['time'],dna['collaboration'],dna['pressure'],pid))
        conn.execute('INSERT INTO project_members(project_id,user_id,role,responsibilities) VALUES(?,?,?,?)',(pid,session['user_id'],'Owner','Project owner'))
        conn.commit(); conn.close(); flash('Project created and Project DNA calculated from your brief.','success'); return redirect(url_for('project',pid=pid))
    return page('Create Project','''<div class="card"><div class="eyebrow">Smart Project Brief Builder</div><h1>Create a project</h1><div class="stepper"><span class="step active">1 Project</span><span class="step">2 Technical</span><span class="step">3 Team</span><span class="step">4 Time & style</span></div><form method="post">
<h2>1. Project information</h2><div class="form-grid"><div><label>Project name *</label><input name="title" required></div><div><label>Members required *</label><input type="number" name="team_size" min="1" max="10" value="3" required></div></div><label>Description *</label><textarea name="description" required></textarea><label>Problem being solved *</label><textarea name="problem" required></textarea><label>Project objective *</label><textarea name="objective" required></textarea>
<h2>2. Technical information</h2><p class="small">Required skills drive technical and complementary matching. Preferred skills are softer signals.</p>{% for sk in skills %}<div class="skill-row"><label>{{sk}}</label><span style="display:grid;grid-template-columns:1fr 1fr;gap:8px"><select name="req_{{sk}}"><option value="0">Required: no</option>{% for n in range(1,6) %}<option value="{{n}}">Required {{n}}/5</option>{% endfor %}</select><select name="pref_{{sk}}"><option value="0">Preferred: no</option>{% for n in range(1,6) %}<option value="{{n}}">Preferred {{n}}/5</option>{% endfor %}</select></span></div>{% endfor %}<label>Interests</label><div class="check-grid">{% for i in interests %}<label class="check"><input type="checkbox" name="interests" value="{{i}}">{{i}}</label>{% endfor %}</div>
<h2>3. Team requirements</h2>{% for n in range(1,6) %}<div class="card"><div class="form-grid"><div><label>Open role {{n}}</label><input name="role_{{n}}" placeholder="e.g. UI/UX Designer"></div><div><label>Responsibilities</label><input name="resp_{{n}}" placeholder="What will they do?"></div></div></div>{% endfor %}
<h2>4. Time, style & communication</h2><div class="form-grid"><div><label>Hours/week</label><input type="number" name="time_hours" min="1" max="80" value="8"></div><div><label>Duration (weeks)</label><input type="number" name="duration_weeks" min="1" max="52" value="8"></div><div><label>Deadline</label><input type="date" name="deadline"></div><div><label>Working style</label><select name="work_pace"><option value="relaxed">Relaxed</option><option value="fast">Fast-paced</option></select></div><div><label>Structure</label><select name="work_structure"><option value="flexible">Flexible</option><option value="structured">Structured</option></select></div><div><label>Communication</label><select name="communication"><option value="mixed">Mixed</option><option value="async">Async</option><option value="sync">Synchronous</option></select></div><div><label>Goal</label><select name="goal"><option value="academic">Academic</option><option value="hackathon">Hackathon</option><option value="competition">Competition</option><option value="portfolio">Portfolio</option><option value="research">Research</option><option value="startup">Startup/business</option><option value="learning">Learning</option></select></div><div><label>Expected commitment</label><select name="commitment"><option value="casual">Casual</option><option value="moderate">Moderate</option><option value="high">Serious</option></select></div></div>
<label>Project personality</label><select name="personality"><option value="">No specific personality</option><option>Hackathon Warriors</option><option>Chill Builders</option><option>Grade Hunters</option><option>Experimental Lab</option><option>Portfolio Builders</option></select>
<h2>Availability</h2><div class="check-grid">{% for a,l in availability %}<label class="check"><input type="checkbox" name="availability" value="{{a}}">{{l}}</label>{% endfor %}</div><div class="tip">Save to calculate Project DNA from your actual inputs. There are no fake/static scores.</div><button class="btn">Create project & analyze</button></form><script>
(function(){const form=document.querySelector('.card form');if(!form)return;const heads=[...form.querySelectorAll('h2')],steps=[];heads.forEach((h,i)=>{const sec=document.createElement('section');sec.className='brief-step';form.insertBefore(sec,h);let node=h;while(node&&node!==heads[i+1]){const next=node.nextSibling;sec.appendChild(node);node=next}steps.push(sec)});const labels=[...document.querySelectorAll('.step')];let current=0;function render(){steps.forEach((x,i)=>x.classList.toggle('active',i===current));labels.forEach((x,i)=>x.classList.toggle('active',i===current));steps.forEach((sec,i)=>{let box=sec.querySelector('.step-actions');if(!box){box=document.createElement('div');box.className='step-actions';const back=document.createElement('button');back.type='button';back.className='btn secondary';back.textContent='Back';const next=document.createElement('button');next.type='button';next.className='btn';next.textContent=i===steps.length-1?'Create project & analyze':'Next';box.append(back,next);sec.appendChild(box)}const bs=box.querySelector('button:first-child'),nx=box.querySelector('button:last-child');bs.style.display=i===0?'none':'inline-flex';bs.onclick=()=>{current=Math.max(0,current-1);render()};nx.onclick=()=>{if(i===steps.length-1){if(form.reportValidity())form.submit()}else{current=Math.min(steps.length-1,current+1);render()}}})}render()})();
</script></div>''',skills=SKILLS,interests=INTERESTS,availability=AVAILABILITY)


@app.route('/join-project/<int:pid>',methods=['POST'])
@login_required
def join_project(pid):
    uid=session['user_id']; conn=db(); p=conn.execute('SELECT * FROM projects WHERE id=?',(pid,)).fetchone()
    if not p: conn.close(); abort(404)
    exists=conn.execute('SELECT 1 FROM project_members WHERE project_id=? AND user_id=?',(pid,uid)).fetchone()
    count=conn.execute('SELECT COUNT(*) FROM project_members WHERE project_id=?',(pid,)).fetchone()[0]
    if exists: flash('You are already on this project.','info')
    elif count >= (p['team_size'] or 1): flash('This project has reached its team size.','error')
    else:
        conn.execute('INSERT INTO project_members(project_id,user_id,role,responsibilities) VALUES(?,?,?,?)',(pid,uid,request.form.get('role','Contributor')[:100],request.form.get('responsibilities','')[:500]))
        conn.commit(); flash('You joined the project. Team analysis has been updated.','success')
    conn.close(); return redirect(url_for('project',pid=pid))

@app.route('/leave-project/<int:pid>',methods=['POST'])
@login_required
def leave_project(pid):
    conn=db(); p=conn.execute('SELECT owner_id FROM projects WHERE id=?',(pid,)).fetchone()
    if p and p['owner_id']!=session['user_id']:
        conn.execute('DELETE FROM project_members WHERE project_id=? AND user_id=?',(pid,session['user_id'])); conn.commit(); flash('You left the project.','success')
    else: flash('The project owner cannot leave their own project.','error')
    conn.close(); return redirect(url_for('project',pid=pid))

# Initialize the database when the module is imported as well as when run directly.
init_db()

@app.errorhandler(404)
def not_found(e): return page('Not Found','<div class="card empty"><h2>Page not found</h2><p>The page you requested does not exist.</p><a class="btn" href="/">Go home</a></div>'),404

if __name__=='__main__':
    init_db(); print('Campus Talent Network running at http://127.0.0.1:5000'); app.run(host='127.0.0.1',port=5000,debug=True)
