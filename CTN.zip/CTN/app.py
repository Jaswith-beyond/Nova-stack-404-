from flask import Flask, request, redirect, url_for, render_template_string, session, flash, abort
import sqlite3
from functools import wraps
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = "change-this-secret-key-in-production"
DB = "campus_talent.db"

SKILLS = ["Python","Machine Learning","SQL","React","JavaScript","UI/UX","Embedded Systems","IoT","Data Analysis","CAD","Robotics","Arduino"]
INTERESTS = ["AI","Hackathons","Research","IoT","Robotics","Web Development","Startups","Data Science","Innovation"]
AVAILABILITY = [("weekday_evening", "Weekday evenings"), ("weekend", "Weekends")]

CSS = r'''
:root{--bg:#f6f8fc;--surface:#fff;--text:#172033;--muted:#64748b;--primary:#2563eb;--primary2:#1d4ed8;--border:#e2e8f0;--success:#15803d;--danger:#b91c1c;--shadow:0 10px 30px rgba(15,23,42,.07)}
*{box-sizing:border-box} body{margin:0;font-family:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;background:var(--bg);color:var(--text);line-height:1.55}
header{position:sticky;top:0;z-index:10;background:rgba(15,32,59,.96);backdrop-filter:blur(10px);color:#fff;border-bottom:1px solid rgba(255,255,255,.08)}
.nav{max-width:1180px;margin:auto;padding:15px 22px;display:flex;align-items:center;justify-content:space-between;gap:20px}.brand{font-weight:800;letter-spacing:-.3px}.brand span{color:#60a5fa}.navlinks{display:flex;align-items:center;gap:7px;flex-wrap:wrap}.navlinks a{color:#dbeafe;text-decoration:none;padding:8px 11px;border-radius:9px;font-size:14px}.navlinks a:hover{background:rgba(255,255,255,.1);color:#fff}
main{max-width:1180px;margin:0 auto;padding:30px 22px 60px}.hero{background:linear-gradient(135deg,#10264a,#1e40af);color:#fff;border-radius:24px;padding:46px;margin-bottom:24px;box-shadow:var(--shadow)}.hero h1{font-size:clamp(32px,5vw,56px);line-height:1.04;margin:0 0 15px;max-width:780px;letter-spacing:-1.8px}.hero p{max-width:700px;color:#dbeafe;font-size:18px}.actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:24px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:18px}.two{display:grid;grid-template-columns:1.2fr .8fr;gap:20px}@media(max-width:800px){.two{grid-template-columns:1fr}.nav{align-items:flex-start}.navlinks{justify-content:flex-end}}
.card{background:var(--surface);border:1px solid var(--border);border-radius:18px;padding:22px;box-shadow:var(--shadow);margin-bottom:18px}.card h2,.card h3{margin-top:0}.eyebrow{text-transform:uppercase;letter-spacing:1.2px;font-size:12px;font-weight:800;color:#93c5fd}.muted,.small{color:var(--muted)}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:7px;background:var(--primary);color:#fff!important;padding:10px 15px;border-radius:10px;text-decoration:none;border:0;cursor:pointer;font-weight:700}.btn:hover{background:var(--primary2)}.btn.secondary{background:#e8eefc;color:#1e40af!important}.btn.danger{background:#fee2e2;color:#991b1b!important}.btn.ghost{background:transparent;color:#dbeafe!important;border:1px solid rgba(255,255,255,.2)}
input,select,textarea{width:100%;padding:11px 12px;border:1px solid #cbd5e1;border-radius:10px;background:#fff;color:var(--text);font:inherit;margin:6px 0 15px}input:focus,select:focus,textarea:focus{outline:3px solid #dbeafe;border-color:#60a5fa}textarea{min-height:110px;resize:vertical}label{font-weight:700;font-size:14px}.form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:0 16px}@media(max-width:650px){.form-grid{grid-template-columns:1fr}}
.check-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:9px;margin:8px 0 18px}.check{display:flex;align-items:center;gap:8px;background:#f8fafc;border:1px solid var(--border);padding:10px;border-radius:10px;font-weight:500}.check input{width:auto;margin:0}.skill-row{display:grid;grid-template-columns:1fr 120px;gap:10px;align-items:center}.badge{display:inline-block;background:#eff6ff;color:#1d4ed8;border:1px solid #dbeafe;border-radius:999px;padding:5px 9px;margin:3px;font-size:12px;font-weight:700}.score{font-size:32px;font-weight:900;color:#1d4ed8}.scorebar{height:9px;background:#e2e8f0;border-radius:99px;overflow:hidden;margin:8px 0 15px}.scorebar i{display:block;height:100%;background:#2563eb;border-radius:99px}.rating{display:inline-flex;align-items:center;gap:5px;font-weight:800;color:#b45309}.stars{letter-spacing:2px;color:#f59e0b}.rating-card{background:linear-gradient(135deg,#fff7ed,#ffffff);border:1px solid #fed7aa}.rating-item{padding:14px 0;border-bottom:1px solid var(--border)}.rating-item:last-child{border-bottom:0}.notice{padding:12px 14px;border-radius:12px;margin-bottom:14px}.success{background:#dcfce7;color:#166534}.error{background:#fee2e2;color:#991b1b}.stat{padding:18px;border-radius:15px;background:#f8fafc;border:1px solid var(--border)}.stat b{display:block;font-size:28px}.row{display:flex;justify-content:space-between;gap:15px;align-items:center;flex-wrap:wrap}.divider{height:1px;background:var(--border);margin:20px 0}.empty{text-align:center;padding:35px 15px;color:var(--muted)}footer{max-width:1180px;margin:auto;padding:0 22px 30px;color:var(--muted);font-size:13px}
'''

LAYOUT = '''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="description" content="Campus Talent Network — connect students by skills, interests and availability."><title>{{title}} · Campus Talent Network</title><style>''' + CSS + '''</style></head><body>
<header><div class="nav"><a class="brand" href="/" style="color:white;text-decoration:none">🎓 Campus <span>Talent</span> Network</a><nav class="navlinks"><a href="/">Home</a>{% if session.get('user_id') %}<a href="/dashboard">Dashboard</a><a href="/find-teammate">Teammates</a><a href="/projects">Projects</a><a href="/profile">Profile</a><a href="/logout">Logout</a>{% else %}<a href="/login">Login</a><a class="btn" href="/register">Join Network</a>{% endif %}</nav></div></header>
<main>{% with messages=get_flashed_messages(with_categories=true) %}{% for category,m in messages %}<div class="notice {{category}}">{{m}}</div>{% endfor %}{% endwith %}{{body|safe}}</main><footer>Campus Talent Network · Local student collaboration prototype</footer></body></html>'''

def db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = db()
    conn.executescript('''
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,email TEXT UNIQUE NOT NULL,password TEXT NOT NULL,phone TEXT,branch TEXT,year INTEGER,availability TEXT,bio TEXT,banned INTEGER DEFAULT 0);
    CREATE TABLE IF NOT EXISTS skills(user_id INTEGER,skill TEXT,level INTEGER,PRIMARY KEY(user_id,skill));
    CREATE TABLE IF NOT EXISTS interests(user_id INTEGER,interest TEXT,PRIMARY KEY(user_id,interest));
    CREATE TABLE IF NOT EXISTS projects(id INTEGER PRIMARY KEY AUTOINCREMENT,owner_id INTEGER,title TEXT NOT NULL,description TEXT,required_skills TEXT,interests TEXT,availability TEXT,team_size INTEGER);
    CREATE TABLE IF NOT EXISTS teammate_queries(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,search_text TEXT NOT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS experience_ratings(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        reviewer_id INTEGER NOT NULL,
        reviewed_id INTEGER NOT NULL,
        experience TEXT NOT NULL,
        rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
        comment TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(reviewer_id, reviewed_id, experience),
        CHECK(reviewer_id != reviewed_id)
    );
    CREATE TABLE IF NOT EXISTS user_reports(reporter_id INTEGER, reported_id INTEGER, PRIMARY KEY(reporter_id,reported_id));
    CREATE TABLE IF NOT EXISTS follows(
        follower_id INTEGER NOT NULL,
        following_id INTEGER NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY(follower_id, following_id),
        CHECK(follower_id != following_id)
    );
    ''')
    columns={r["name"] for r in conn.execute("PRAGMA table_info(users)")}
    if "phone" not in columns: conn.execute("ALTER TABLE users ADD COLUMN phone TEXT")
    if "bio" not in columns: conn.execute("ALTER TABLE users ADD COLUMN bio TEXT")
    if "banned" not in columns: conn.execute("ALTER TABLE users ADD COLUMN banned INTEGER DEFAULT 0")
    if conn.execute("SELECT COUNT(*) FROM projects").fetchone()[0]==0:
        conn.executemany("INSERT INTO projects(owner_id,title,description,required_skills,interests,availability,team_size) VALUES(NULL,?,?,?,?,?,?)",[
            ("Smart Campus IoT","Monitor classroom energy usage with connected sensors.","IoT:4,Python:3,Embedded Systems:3","IoT,Robotics","weekend",3),
            ("AI Student Assistant","Build an AI assistant for campus FAQs and student services.","Python:4,Machine Learning:4,SQL:3","AI,Research","weekday_evening",3),
            ("Campus Event App","Create a modern event discovery and registration platform.","React:4,JavaScript:4,UI/UX:3","Web Development,Hackathons","weekend",2)])
    conn.commit(); conn.close()

def login_required(f):
    @wraps(f)
    def wrapper(*args,**kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        # Immediately invalidate an active session if the account has reached
        # the 5-report threshold and has been banned.
        conn=db(); u=conn.execute("SELECT banned FROM users WHERE id=?",(session["user_id"],)).fetchone(); conn.close()
        if not u or u["banned"]:
            session.clear()
            flash("Your account has been permanently blocked after reaching the report threshold.","error")
            return redirect(url_for("login"))
        return f(*args,**kwargs)
    return wrapper

def user_data(uid):
    conn=db(); u=conn.execute("SELECT * FROM users WHERE id=?",(uid,)).fetchone()
    skills={r["skill"]:r["level"] for r in conn.execute("SELECT skill,level FROM skills WHERE user_id=? ORDER BY skill",(uid,))}
    interests={r["interest"] for r in conn.execute("SELECT interest FROM interests WHERE user_id=? ORDER BY interest",(uid,))}; conn.close()
    return u,skills,interests

def parse_project(p):
    req={}
    for item in (p["required_skills"] or "").split(","):
        if ":" in item:
            s,l=item.split(":",1)
            try:req[s.strip()]=int(l)
            except ValueError: pass
    ints={x.strip() for x in (p["interests"] or "").split(",") if x.strip()}
    av={x.strip() for x in (p["availability"] or "").split(",") if x.strip()}
    return req,ints,av

def score_student(uid,required,project_interests,project_availability):
    u,skills,interests=user_data(uid)
    max_points=sum(required.values()); points=sum(min(skills.get(s,0)/lvl,1)*lvl for s,lvl in required.items()) if max_points else 0
    skill=(points/max_points*100) if max_points else 0
    interest=(len(interests&project_interests)/len(project_interests)*100) if project_interests else 0
    avail={x.strip() for x in (u["availability"] or "").split(",") if x.strip()}
    availability=(len(avail&project_availability)/len(project_availability)*100) if project_availability else 0
    return round(.60*skill+.25*interest+.15*availability,1)

def get_experience_summary(uid):
    conn=db()
    row=conn.execute('SELECT AVG(rating) AS avg_rating, COUNT(*) AS count FROM experience_ratings WHERE reviewed_id=?',(uid,)).fetchone()
    recent=conn.execute('SELECT er.*, u.name AS reviewer_name FROM experience_ratings er JOIN users u ON u.id=er.reviewer_id WHERE er.reviewed_id=? ORDER BY er.id DESC LIMIT 5',(uid,)).fetchall()
    conn.close()
    return (round(row['avg_rating'],1) if row['avg_rating'] is not None else None, row['count'], recent)

def find_teammates(uid, query="", limit=10):
    """Rank teammates. If a skill/attribute is searched, matching people are
    ranked primarily by their rating in that attribute (highest first).
    Otherwise use the normal compatibility score.
    """
    me,my_skills,my_interests=user_data(uid); my_names=set(my_skills); my_av={x.strip() for x in (me["availability"] or "").split(",") if x.strip()}
    query=(query or "").strip().lower()
    conn=db(); ids=[r["id"] for r in conn.execute("SELECT id FROM users WHERE id!=? AND banned=0",(uid,))]; conn.close(); out=[]

    # Resolve a search to a known skill/interest. This makes searches such as
    # "CAD" behave as an attribute lookup instead of merely saving a note.
    matched_skill=next((skill for skill in SKILLS if skill.lower()==query), None)
    matched_skill = matched_skill or next((skill for skill in SKILLS if query and query in skill.lower()), None)
    matched_interest=next((interest for interest in INTERESTS if interest.lower()==query), None)
    matched_interest = matched_interest or next((interest for interest in INTERESTS if query and query in interest.lower()), None)

    for oid in ids:
        u,s,i=user_data(oid); names=set(s); union=my_names|names; complement=my_names^names
        interest=len(my_interests&i)/max(len(my_interests),1)*100
        complement_score=len(complement)/max(len(union),1)*100
        other_av={x.strip() for x in (u["availability"] or "").split(",") if x.strip()}
        availability=len(my_av&other_av)/max(len(my_av),1)*100
        overlap=len(my_names&names)/max(len(my_names),1)*100
        total=.40*complement_score+.25*interest+.20*availability+.15*overlap

        attribute_rating=None
        attribute_match=False
        if matched_skill:
            attribute_rating=s.get(matched_skill,0)
            attribute_match=matched_skill in s
        elif matched_interest:
            attribute_rating=1 if matched_interest in i else 0
            attribute_match=matched_interest in i
        elif query:
            # Generic text search across skills, interests, branch and name.
            haystack=" ".join([u["name"],u["branch"],*s.keys(),*i]).lower()
            attribute_match=query in haystack

        experience_rating, experience_count, _ = get_experience_summary(oid)
        out.append({"user":u,"skills":s,"interests":i,"score":round(total,1),
                    "attribute_rating":attribute_rating,"attribute_match":attribute_match,
                    "experience_rating":experience_rating,"experience_count":experience_count})

    if matched_skill or matched_interest:
        # For an attribute search, matching people come first, and the highest
        # rating is the primary sort key. Compatibility score breaks ties.
        out.sort(key=lambda x:(x["attribute_match"], x["attribute_rating"] or 0, x["experience_rating"] or 0, x["score"]), reverse=True)
    elif query:
        out=[x for x in out if x["attribute_match"]]
        out.sort(key=lambda x:x["score"], reverse=True)
    else:
        out.sort(key=lambda x:(x["score"], x["experience_rating"] or 0), reverse=True)
    return out[:limit]

def page(title,body,**ctx): return render_template_string(LAYOUT,title=title,body=render_template_string(body,**ctx))

def profile_form(u=None,skills=None,interests=None):
    return render_template_string(PROFILE_FORM, u=u, skills=skills or {}, interests=interests or set(), all_skills=SKILLS, all_interests=INTERESTS, availability=AVAILABILITY)

PROFILE_FORM='''<form method="post"><div class="form-grid"><div><label>Full name</label><input name="name" value="{{u.name if u else ''}}" required></div><div><label>Email</label><input type="email" name="email" value="{{u.email if u else ''}}" required></div><div><label>Phone / WhatsApp</label><input name="phone" value="{{u.phone if u else ''}}" placeholder="+91 98765 43210"></div><div><label>Branch</label><input name="branch" value="{{u.branch if u else ''}}" placeholder="e.g. CSE" required></div><div><label>Year</label><select name="year">{% for y in range(1,5) %}<option value="{{y}}" {% if u and u.year==y %}selected{% endif %}>Year {{y}}</option>{% endfor %}</select></div>{% if not u %}<div><label>Password</label><input type="password" name="password" minlength="6" required></div>{% endif %}</div>
<label>About You (max 50 words)</label><textarea name='bio' maxlength='350' placeholder='Tell others about yourself in around 50 words'>{{u.bio if u and u.bio else ''}}</textarea><label>Availability</label><div class="check-grid">{% for value,label in availability %}<label class="check"><input type="checkbox" name="availability" value="{{value}}" {% if u and value in (u.availability or '').split(',') %}checked{% endif %}> {{label}}</label>{% endfor %}</div>
<h3>Skills <span class="small">(0 = none, 5 = expert)</span></h3>{% for s in all_skills %}<div class="skill-row"><label>{{s}}</label><select name="skill_{{s}}"><option value="0">0</option>{% for n in range(1,6) %}<option value="{{n}}" {% if skills.get(s,0)==n %}selected{% endif %}>{{n}} / 5</option>{% endfor %}</select></div>{% endfor %}
<h3>Interests</h3><div class="check-grid">{% for i in all_interests %}<label class="check"><input type="checkbox" name="interests" value="{{i}}" {% if i in interests %}checked{% endif %}> {{i}}</label>{% endfor %}</div><button class="btn" type="submit">{{'Save Changes' if u else 'Create Student Account'}}</button></form>'''

@app.route('/')
def home():
    return page('Home','''<section class="hero"><div class="eyebrow">Student collaboration platform</div><h1>Find the right people for your next big project.</h1><p>Build your student profile, discover complementary teammates and match with campus projects using skills, interests and availability.</p><div class="actions">{% if session.get('user_id') %}<a class="btn" href="/find-teammate">Find teammates</a><a class="btn ghost" href="/projects">Explore projects</a>{% else %}<a class="btn" href="/register">Create your profile</a><a class="btn ghost" href="/login">Sign in</a>{% endif %}</div></section><div class="grid"><div class="card"><h3>🤝 Smart teammate matching</h3><p class="muted">Recommendations prioritize complementary skills, shared interests and schedule overlap.</p></div><div class="card"><h3>📊 Project matching</h3><p class="muted">See which projects fit your current skills and interests.</p></div><div class="card"><h3>⭐ Team experience ratings</h3><p class="muted">Learn how students performed in previous collaborations through ratings and feedback.</p></div><div class="card"><h3>🔒 Follow to connect</h3><p class="muted">Follow a teammate to unlock their contact details and connect outside the platform.</p></div></div>''')

@app.route('/register',methods=['GET','POST'])
def register():
    if request.method=='POST':
        name=request.form['name'].strip(); email=request.form['email'].strip().lower(); password=request.form['password']; phone=request.form.get('phone','').strip(); branch=request.form['branch'].strip(); year=int(request.form['year']); availability=','.join(request.form.getlist('availability')); bio=request.form.get('bio','').strip()
        if len(bio.split()) > 50:
            flash('About You must be 50 words or fewer.','error')
            return page('Register','<div class="two"><div class="card"><h2>Create your student profile</h2><p class="muted">The more complete your profile, the better the matches.</p>{{form|safe}}</div><div class="card"><h3>What you get</h3><p>✓ Ranked teammate recommendations</p><p>✓ Project compatibility scores</p><p>✓ Skills & interest profile</p><p>✓ Contact details for collaboration</p></div></div>',form=profile_form())
        conn=db()
        try:
            cur=conn.execute('INSERT INTO users(name,email,password,phone,branch,year,availability,bio) VALUES(?,?,?,?,?,?,?,?)',(name,email,generate_password_hash(password),phone,branch,year,availability,request.form.get('bio','').strip()[:350])); uid=cur.lastrowid
            save_profile_rows(conn,uid,request.form); conn.commit(); session['user_id']=uid; flash('Welcome! Your student profile is ready.','success'); return redirect(url_for('dashboard'))
        except sqlite3.IntegrityError: conn.rollback(); flash('That email is already registered. Please log in instead.','error')
        finally: conn.close()
    return page('Register','<div class="two"><div class="card"><h2>Create your student profile</h2><p class="muted">The more complete your profile, the better the matches.</p>{{form|safe}}</div><div class="card"><h3>What you get</h3><p>✓ Ranked teammate recommendations</p><p>✓ Project compatibility scores</p><p>✓ Skills & interest profile</p><p>✓ Contact details for collaboration</p></div></div>',form=profile_form())

def save_profile_rows(conn,uid,form):
    for s in SKILLS:
        level=int(form.get('skill_'+s,0) or 0)
        if level: conn.execute('INSERT OR REPLACE INTO skills(user_id,skill,level) VALUES(?,?,?)',(uid,s,level))
        else: conn.execute('DELETE FROM skills WHERE user_id=? AND skill=?',(uid,s))
    conn.execute('DELETE FROM interests WHERE user_id=?',(uid,))
    for i in form.getlist('interests'):
        if i in INTERESTS: conn.execute('INSERT OR IGNORE INTO interests(user_id,interest) VALUES(?,?)',(uid,i))

@app.route('/login',methods=['GET','POST'])
def login():
    if request.method=='POST':
        email=request.form['email'].strip().lower(); password=request.form['password']; conn=db(); u=conn.execute('SELECT * FROM users WHERE email=? AND banned=0',(email,)).fetchone(); conn.close()
        valid=False
        if u:
            try: valid=check_password_hash(u['password'],password)
            except ValueError: valid=(u['password']==password) # migrate legacy demo accounts on successful login
        if valid:
            if u['password']==password: migrate_password(u['id'],password)
            session.clear(); session['user_id']=u['id']; return redirect(url_for('dashboard'))
        flash('Invalid email or password.','error')
    return page('Login','''<div class="card" style="max-width:520px;margin:35px auto"><h2>Welcome back</h2><p class="muted">Sign in to access your teammate and project matches.</p><form method="post"><label>Email</label><input type="email" name="email" required><label>Password</label><input type="password" name="password" required><button class="btn">Sign in</button></form><div class="divider"></div><p class="small">New here? <a href="/register">Create an account</a></p></div>''')

def migrate_password(uid,password):
    conn=db(); conn.execute('UPDATE users SET password=? WHERE id=?',(generate_password_hash(password),uid)); conn.commit(); conn.close()

@app.route('/logout')
def logout(): session.clear(); return redirect(url_for('home'))

@app.route('/dashboard')
@login_required
def dashboard():
    u,skills,interests=user_data(session['user_id']); conn=db(); student_count=conn.execute('SELECT COUNT(*) FROM users').fetchone()[0]; project_count=conn.execute('SELECT COUNT(*) FROM projects').fetchone()[0]; conn.close()
    return page('Dashboard','''<div class="row"><div><div class="eyebrow">Dashboard</div><h1>Hi, {{u.name.split()[0]}} 👋</h1><p class="muted">Here’s your collaboration overview.</p></div><a class="btn" href="/find-teammate">Find teammates</a></div><div class="grid"><div class="stat"><span class="small">Students</span><b>{{student_count}}</b></div><div class="stat"><span class="small">Projects</span><b>{{project_count}}</b></div><div class="stat"><span class="small">Your skills</span><b>{{skills|length}}</b></div><div class="stat"><span class="small">Interests</span><b>{{interests|length}}</b></div></div><div class="two" style="margin-top:20px"><div class="card"><h2>Your profile</h2><p><b>{{u.branch}}</b> · Year {{u.year}}</p><p class="muted">{{u.email}}{% if u.phone %} · {{u.phone}}{% endif %}</p>{% for k,v in skills.items() %}<span class="badge">{{k}} {{v}}/5</span>{% endfor %}<div class="actions"><a class="btn secondary" href="/profile">Edit profile</a><a class="btn" href="/projects">Explore projects</a></div></div><div class="card"><h2>Quick start</h2><p>1. Complete your skills and interests.</p><p>2. Find teammates with complementary strengths.</p><p>3. Explore projects and build a team.</p></div></div>''',u=u,skills=skills,interests=interests,student_count=student_count,project_count=project_count)

@app.route('/profile',methods=['GET','POST'])
@login_required
def profile():
    uid=session['user_id']; u,skills,interests=user_data(uid)
    if request.method=='POST':
        name=request.form['name'].strip(); email=request.form['email'].strip().lower(); phone=request.form.get('phone','').strip(); branch=request.form['branch'].strip(); year=int(request.form['year']); availability=','.join(request.form.getlist('availability')); bio=request.form.get('bio','').strip()
        if len(bio.split()) > 50:
            flash('About You must be 50 words or fewer.','error')
            return page('My Profile','<div class="card"><div class="row"><div><div class="eyebrow">Profile</div><h1>My profile</h1></div><a class="btn secondary" href="/find-teammate">View matches</a></div>{{form|safe}}</div>',form=profile_form(u,skills,interests))
        conn=db()
        try:
            conn.execute('UPDATE users SET name=?,email=?,phone=?,branch=?,year=?,availability=?,bio=? WHERE id=?',(name,email,phone,branch,year,availability,bio[:350],uid)); save_profile_rows(conn,uid,request.form); conn.commit(); flash('Profile updated successfully.','success'); return redirect(url_for('profile'))
        except sqlite3.IntegrityError: conn.rollback(); flash('That email is already in use.','error')
        finally: conn.close()
        u,skills,interests=user_data(uid)
    return page('My Profile','<div class="card"><div class="row"><div><div class="eyebrow">Profile</div><h1>My profile</h1></div><a class="btn secondary" href="/find-teammate">View matches</a></div>{{form|safe}}</div>',form=profile_form(u,skills,interests))

@app.route('/find-teammate',methods=['GET','POST'])
@login_required
def find_teammate():
    uid=session['user_id']
    # Always initialize the search text. A normal GET request has no form
    # payload, so referencing a POST-only local variable caused an
    # UnboundLocalError on /find-teammate.
    text=request.values.get('search_text','').strip()
    conn=db()
    if request.method=='POST' and text:
        conn.execute('INSERT INTO teammate_queries(user_id,search_text) VALUES(?,?)',(uid,text))
        conn.commit()
        flash('Search saved. Matching students are ranked by the searched attribute.','success')
    queries=conn.execute('SELECT * FROM teammate_queries WHERE user_id=? ORDER BY id DESC',(uid,)).fetchall()
    conn.close()
    results=find_teammates(uid, text)
    return page('Find Teammates','''<div class="row"><div><div class="eyebrow">Team formation</div><h1>Find your teammates</h1><p class="muted">Recommendations use complementary skills, shared interests, availability and skill overlap.</p></div><a class="btn secondary" href="/profile">Improve my profile</a></div><div class="card"><form method="get"><label>Search for a skill or attribute</label><input name="search_text" value="{{search_text}}" placeholder="e.g. CAD, Python, React, Robotics"><button class="btn" type="submit">Search teammates</button>{% if search_text %}<a class="btn secondary" href="/find-teammate">Clear</a>{% endif %}</form><p class="small">When you search for a skill such as <b>CAD</b>, students who have CAD are shown first and ranked by their <b>CAD skill rating from highest to lowest</b>. Community team-experience rating then helps break ties. Without a search, recommendations use 40% complementary skills · 25% shared interests · 20% availability · 15% skill overlap.</p></div><h2>Recommended students</h2>{% for r in results %}<div class="card"><div class="row"><div><h3>#{{loop.index}} {{r.user.name}}</h3><p class="muted">{{r.user.branch}} · Year {{r.user.year}}</p></div><div style="min-width:160px"><div class="score">{{r.score}}%</div><div class="scorebar"><i style="width:{{r.score}}%"></i></div></div></div><div><b>Skills</b><br>{% for k,v in r.skills.items() %}<span class="badge">{{k}} {{v}}/5</span>{% endfor %}</div>{% if r.experience_rating %}<p class="rating"><span class="stars">★★★★★</span> {{r.experience_rating}}/5 <span class="muted">({{r.experience_count}} team experience{{'' if r.experience_count==1 else 's'}})</span></p>{% else %}<p class="small">No team experience ratings yet</p>{% endif %}<p><b>Interests:</b> {{r.interests|join(', ') if r.interests else 'Not specified'}}</p><p><b>Availability:</b> {{r.user.availability or 'Not specified'}}</p><a class="btn" href="/teammate/{{r.user.id}}">View profile & follow</a></div>{% else %}<div class="card empty">No other students are registered yet. Add another student account to test matching.</div>{% endfor %}<div class="card"><h3>Saved search notes</h3>{% for q in queries %}<div class="row" style="padding:10px 0;border-bottom:1px solid #eee"><span>{{q.search_text}} <span class="small">· {{q.created_at}}</span></span><form method="post" action="/delete-query/{{q.id}}"><button class="btn danger" type="submit">Delete</button></form></div>{% else %}<p class="small">No saved notes.</p>{% endfor %}</div>''',results=results,queries=queries,search_text=text)

@app.route('/delete-query/<int:qid>',methods=['POST'])
@login_required
def delete_query(qid):
    conn=db(); conn.execute('DELETE FROM teammate_queries WHERE id=? AND user_id=?',(qid,session['user_id'])); conn.commit(); conn.close(); flash('Search note deleted.','success'); return redirect(url_for('find_teammate'))

@app.route('/rate-teammate/<int:uid>',methods=['GET','POST'])
@login_required
def rate_teammate(uid):
    reviewer_id=session['user_id']
    if uid==reviewer_id:
        flash('You cannot rate yourself.','error'); return redirect(url_for('profile'))
    reviewed,_,_=user_data(uid)
    if not reviewed: abort(404)
    if request.method=='POST':
        experience=request.form.get('experience','').strip()
        comment=request.form.get('comment','').strip()
        try: rating=int(request.form.get('rating','0'))
        except ValueError: rating=0
        if not experience or len(experience)<3:
            flash('Please enter the hackathon, project or event you worked on together.','error')
        elif rating not in range(1,6):
            flash('Please choose a rating from 1 to 5.','error')
        else:
            conn=db()
            try:
                conn.execute('INSERT INTO experience_ratings(reviewer_id,reviewed_id,experience,rating,comment) VALUES(?,?,?,?,?)',(reviewer_id,uid,experience,rating,comment[:500]))
                conn.commit(); flash('Your teammate experience rating was submitted.','success'); return redirect(url_for('teammate',uid=uid))
            except sqlite3.IntegrityError:
                conn.rollback(); flash('You have already rated this teammate for that experience. Use a different project or hackathon.','error')
            finally: conn.close()
    avg,count,recent=get_experience_summary(uid)
    body="""<div class="card" style="max-width:700px;margin:auto"><a href="/teammate/{{u.id}}">← Back to {{u.name}}</a><div class="eyebrow" style="margin-top:20px">Post-project feedback</div><h1>Rate {{u.name}}</h1><p class="muted">Only rate someone you have genuinely worked with. Your feedback helps other students choose reliable teammates.</p><form method="post"><label>Hackathon / project / event</label><input name="experience" required maxlength="120" placeholder="e.g. Smart India Hackathon 2026"><label>How well did they perform?</label><div class="check-grid" style="grid-template-columns:repeat(5,1fr)">{% for n in range(1,6) %}<label class="check" style="justify-content:center"><input type="radio" name="rating" value="{{n}}" required> {{n}} ★</label>{% endfor %}</div><label>Comments <span class="small">(optional)</span></label><textarea name="comment" maxlength="500" placeholder="What did they do well? Were they reliable, collaborative and effective?"></textarea><button class="btn" type="submit">Submit experience rating</button></form>{% if avg %}<div class="divider"></div><p class="rating"><span class="stars">★★★★★</span> {{avg}} / 5 · {{count}} experience rating{{'' if count==1 else 's'}}</p>{% endif %}</div>"""
    return page('Rate Teammate',body,u=reviewed,avg=avg,count=count,recent=recent)


@app.route('/report-user/<int:uid>',methods=['POST'])
@login_required
def report_user(uid):
    if uid==session['user_id']: return redirect(url_for('teammate',uid=uid))
    conn=db()
    conn.execute('INSERT OR IGNORE INTO user_reports(reporter_id,reported_id) VALUES(?,?)',(session['user_id'],uid))
    count=conn.execute('SELECT COUNT(*) FROM user_reports WHERE reported_id=?',(uid,)).fetchone()[0]
    if count>=5:
        conn.execute('UPDATE users SET banned=1 WHERE id=?',(uid,))
    conn.commit(); conn.close(); flash('User reported.','success'); return redirect(url_for('teammate',uid=uid))

@app.route('/follow/<int:uid>', methods=['POST'])
@login_required
def follow_user(uid):
    follower_id=session['user_id']
    if uid==follower_id:
        flash('You cannot follow yourself.','error')
        return redirect(url_for('profile'))
    conn=db(); target=conn.execute('SELECT id,name,banned FROM users WHERE id=?',(uid,)).fetchone()
    if not target or target['banned']:
        conn.close(); abort(404)
    try:
        conn.execute('INSERT INTO follows(follower_id,following_id) VALUES(?,?)',(follower_id,uid))
        conn.commit(); flash(f'You are now following {target["name"]}. Contact details are unlocked.','success')
    except sqlite3.IntegrityError:
        conn.rollback(); flash('You already follow this student.','success')
    finally:
        conn.close()
    return redirect(url_for('teammate',uid=uid))

@app.route('/unfollow/<int:uid>', methods=['POST'])
@login_required
def unfollow_user(uid):
    if uid==session['user_id']:
        return redirect(url_for('profile'))
    conn=db(); conn.execute('DELETE FROM follows WHERE follower_id=? AND following_id=?',(session['user_id'],uid)); conn.commit(); conn.close()
    flash('You unfollowed this student. Their contact details are locked again.','success')
    return redirect(url_for('teammate',uid=uid))

@app.route('/teammate/<int:uid>')
@login_required
def teammate(uid):
    if uid==session['user_id']: return redirect(url_for('profile'))
    u,skills,interests=user_data(uid)
    if not u: abort(404)
    matches=find_teammates(session['user_id'],limit=100); match=next((x for x in matches if x['user']['id']==uid),None)
    score=match['score'] if match else None
    avg,count,recent=get_experience_summary(uid)
    conn=db(); following=conn.execute('SELECT 1 FROM follows WHERE follower_id=? AND following_id=?',(session['user_id'],uid)).fetchone() is not None; conn.close()
    body="""<div class="card"><a href="/find-teammate">← Back to recommendations</a><div class="row" style="margin-top:20px"><div><div class="eyebrow">Student profile</div><h1>{{u.name}}</h1><p class="muted">{{u.branch}} · Year {{u.year}}</p>{% if avg %}<p class="rating"><span class="stars">★★★★★</span> {{avg}}/5 <span class="muted">({{count}} experience{{'' if count==1 else 's'}})</span></p>{% else %}<p class="muted">No teammate experience ratings yet</p>{% endif %}</div>{% if score is not none %}<div><div class="score">{{score}}% match</div><div class="scorebar"><i style="width:{{score}}%"></i></div></div>{% endif %}</div><div class="divider"></div><div class='actions'><a class='btn' href='/rate-teammate/{{u.id}}'>⭐ Rate this teammate</a><form method='post' action='/report-user/{{u.id}}' style='display:inline'><button class='btn danger' type='submit'>Report Imposter</button></form></div><p class="small">Worked with {{u.name}} at a hackathon or project? Share your experience to help future teams make better choices.</p><div class="divider"></div><h3>Contact details</h3>{% if following %}<div class="notice success">✓ You follow {{u.name}}. Their contact details are unlocked.</div><p>📧 <a href="mailto:{{u.email}}">{{u.email}}</a></p><p>📱 {% if u.phone %}<a href="tel:{{u.phone}}">{{u.phone}}</a>{% else %}Not provided{% endif %}</p><form method="post" action="/unfollow/{{u.id}}"><button class="btn secondary" type="submit">Unfollow {{u.name}}</button></form>{% else %}<div class="notice" style="background:#eff6ff;color:#1e40af">🔒 Follow {{u.name}} to unlock their contact details. You can still view their skills, interests and team experience.</div><form method="post" action="/follow/{{u.id}}"><button class="btn" type="submit">+ Follow {{u.name}}</button></form>{% endif %}<h3>Skills</h3>{% for k,v in skills.items() %}<span class="badge">{{k}} {{v}}/5</span>{% else %}<p class="muted">No skills listed.</p>{% endfor %}<h3>Interests</h3><p>{{interests|join(', ') if interests else 'Not specified'}}</p><h3>About</h3><p>{{u.bio or 'No description provided.'}}</p><h3>Availability</h3><p>{{u.availability or 'Not specified'}}</p></div>{% if recent %}<div class="card rating-card"><div class="row"><h2>Team experience</h2><span class="small">{{count}} community rating{{'' if count==1 else 's'}}</span></div>{% for r in recent %}<div class="rating-item"><div class="row"><b>{{r.experience}}</b><span class="rating"><span class="stars">{{'★' * r.rating}}{{'☆' * (5-r.rating)}}</span> {{r.rating}}/5</span></div>{% if r.comment %}<p>{{r.comment}}</p>{% endif %}<p class="small">Shared by {{r.reviewer_name}} · {{r.created_at}}</p></div>{% endfor %}</div>{% endif %}"""
    return page('Teammate Profile',body,u=u,skills=skills,interests=interests,score=score,avg=avg,count=count,recent=recent,following=following)

@app.route('/projects')
@login_required
def projects_page():
    conn=db(); ps=conn.execute('SELECT p.*,u.name AS owner_name FROM projects p LEFT JOIN users u ON p.owner_id=u.id ORDER BY p.id DESC').fetchall(); conn.close(); cards=[]
    for p in ps:
        req,ints,av=parse_project(p); cards.append((p,score_student(session['user_id'],req,ints,av)))
    cards.sort(key=lambda x:x[1],reverse=True)
    return page('Projects','''<div class="row"><div><div class="eyebrow">Discover</div><h1>Project marketplace</h1><p class="muted">Projects ranked by your skills, interests and availability.</p></div><a class="btn" href="/add-project">+ Create project</a></div>{% for p,score in cards %}<div class="card"><div class="row"><div><h2>{{p.title}}</h2><p>{{p.description}}</p><p class="small">{% if p.owner_name %}Created by {{p.owner_name}} · {% endif %}Team size {{p.team_size}}</p></div><div style="min-width:160px"><div class="score">{{score}}%</div><div class="scorebar"><i style="width:{{score}}%"></i></div></div></div><p><b>Required skills:</b> {{p.required_skills or 'Flexible'}}</p><p><b>Interests:</b> {{p.interests or 'Any'}}</p><a class="btn" href="/project/{{p.id}}">View team suggestions</a></div>{% endfor %}''',cards=cards)

@app.route('/project/<int:pid>')
@login_required
def project(pid):
    conn=db(); p=conn.execute('SELECT p.*,u.name AS owner_name FROM projects p LEFT JOIN users u ON p.owner_id=u.id WHERE p.id=?',(pid,)).fetchone(); ids=conn.execute('SELECT id FROM users WHERE id!=?',(session['user_id'],)).fetchall(); conn.close()
    if not p: abort(404)
    req,ints,av=parse_project(p); ranked=sorted([(r['id'],score_student(r['id'],req,ints,av)) for r in ids],key=lambda x:x[1],reverse=True)[:p['team_size']]; people=[]
    for uid,score in ranked: u,_,_=user_data(uid); people.append((u,score))
    return page('Project Team','''<div class="card"><a href="/projects">← Back to projects</a><div class="eyebrow" style="margin-top:20px">Project</div><h1>{{p.title}}</h1><p>{{p.description}}</p><p><b>Required skills:</b> {{p.required_skills or 'Flexible'}}</p><p><b>Interests:</b> {{p.interests or 'Any'}}</p></div><div class="card"><h2>Suggested team</h2>{% for u,score in people %}<div class="row" style="padding:15px 0;border-bottom:1px solid #eee"><div><h3>{{u.name}}</h3><span class="muted">{{u.branch}} · Year {{u.year}}</span></div><div><b>{{score}}%</b> match</div></div>{% else %}<div class="empty">No other students are available yet.</div>{% endfor %}</div>''',p=p,people=people)

@app.route('/add-project',methods=['GET','POST'])
@login_required
def add_project():
    if request.method=='POST':
        title=request.form['title'].strip(); description=request.form.get('description','').strip(); team_size=max(1,min(10,int(request.form['team_size']))); skills=[]
        for s in SKILLS:
            level=int(request.form.get('req_'+s,0) or 0)
            if level: skills.append(f'{s}:{level}')
        interests=','.join(i for i in request.form.getlist('interests') if i in INTERESTS); availability=','.join(a for a,_ in AVAILABILITY if a in request.form.getlist('availability'))
        conn=db(); conn.execute('INSERT INTO projects(owner_id,title,description,required_skills,interests,availability,team_size) VALUES(?,?,?,?,?,?,?)',(session['user_id'],title,description,','.join(skills),interests,availability,team_size)); conn.commit(); conn.close(); flash('Project created successfully.','success'); return redirect(url_for('projects_page'))
    return page('Create Project','''<div class="card"><div class="eyebrow">Build a team</div><h1>Create a project</h1><form method="post"><label>Project title</label><input name="title" required placeholder="e.g. Smart Campus Assistant"><label>Description</label><textarea name="description" placeholder="What are you building and why?"></textarea><label>Team size</label><input type="number" name="team_size" min="1" max="10" value="3"><h3>Required skills</h3>{% for s in skills %}<div class="skill-row"><label>{{s}}</label><select name="req_{{s}}"><option value="0">Not required</option>{% for n in range(1,6) %}<option value="{{n}}">{{n}} / 5</option>{% endfor %}</select></div>{% endfor %}<h3>Interests</h3><div class="check-grid">{% for i in interests %}<label class="check"><input type="checkbox" name="interests" value="{{i}}"> {{i}}</label>{% endfor %}</div><h3>About</h3><p>{{u.bio or 'No description provided.'}}</p><h3>Availability</h3><div class="check-grid">{% for a,label in availability %}<label class="check"><input type="checkbox" name="availability" value="{{a}}"> {{label}}</label>{% endfor %}</div><button class="btn">Create project</button></form></div>''',skills=SKILLS,interests=INTERESTS,availability=AVAILABILITY)

# Initialize the database when the module is imported as well as when run directly.
init_db()

@app.errorhandler(404)
def not_found(e): return page('Not Found','<div class="card empty"><h2>Page not found</h2><p>The page you requested does not exist.</p><a class="btn" href="/">Go home</a></div>'),404

if __name__=='__main__':
    init_db(); print('Campus Talent Network running at http://127.0.0.1:5000'); app.run(host='127.0.0.1',port=5000,debug=True)
