from pathlib import Path
p=Path('/mnt/data/v4work/campus_talent_network_local_v4_fixed/app.py')
s=p.read_text()
# Add follows table
old="""    CREATE TABLE IF NOT EXISTS user_reports(reporter_id INTEGER, reported_id INTEGER, PRIMARY KEY(reporter_id,reported_id));\n    ''')"""
new="""    CREATE TABLE IF NOT EXISTS user_reports(reporter_id INTEGER, reported_id INTEGER, PRIMARY KEY(reporter_id,reported_id));\n    CREATE TABLE IF NOT EXISTS follows(\n        follower_id INTEGER NOT NULL,\n        following_id INTEGER NOT NULL,\n        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,\n        PRIMARY KEY(follower_id, following_id),\n        CHECK(follower_id != following_id)\n    );\n    ''')"""
s=s.replace(old,new)
# Find teammate card contact link -> profile view is okay. Add follow info on profile by replacing contact section.
old="""<div class=\'divider\'></div><h3>Contact</h3><p>📧 <a href=\"mailto:{{u.email}}\">{{u.email}}</a></p><p>📱 {% if u.phone %}<a href=\"tel:{{u.phone}}\">{{u.phone}}</a>{% else %}Not provided{% endif %}</p><h3>Skills</h3>"""
new="""<div class='divider'></div><h3>Contact details</h3>{% if following %}<div class='notice success'>✓ You follow {{u.name}}. Their contact details are unlocked.</div><p>📧 <a href=\"mailto:{{u.email}}\">{{u.email}}</a></p><p>📱 {% if u.phone %}<a href=\"tel:{{u.phone}}\">{{u.phone}}</a>{% else %}Not provided{% endif %}</p>{% else %}<div class='notice' style='background:#eff6ff;color:#1e40af'>🔒 Follow {{u.name}} to unlock their contact details. You can still view their skills, interests and team experience.</div><form method='post' action='/follow/{{u.id}}'><button class='btn' type='submit'>+ Follow {{u.name}}</button></form>{% endif %}<h3>Skills</h3>"""
if old not in s: print('contact pattern not found')
s=s.replace(old,new)
# Add following arg
old="""    avg,count,recent=get_experience_summary(uid)\n    body=\"\"\"<div class=\"card\">"""
new="""    avg,count,recent=get_experience_summary(uid)\n    conn=db(); following=conn.execute('SELECT 1 FROM follows WHERE follower_id=? AND following_id=?',(session['user_id'],uid)).fetchone() is not None; conn.close()\n    body=\"\"\"<div class=\"card\">"""
s=s.replace(old,new,1)
# Add following to page call in teammate only; target exact final line near teammate
old="""    return page('Teammate Profile',body,u=u,skills=skills,interests=interests,score=score,avg=avg,count=count,recent=recent)\n"""
new="""    return page('Teammate Profile',body,u=u,skills=skills,interests=interests,score=score,avg=avg,count=count,recent=recent,following=following)\n"""
s=s.replace(old,new,1)
# Insert follow route before teammate route
marker="""@app.route('/teammate/<int:uid>')\n@login_required\ndef teammate(uid):\n"""
route="""@app.route('/follow/<int:uid>', methods=['POST'])\n@login_required\ndef follow_user(uid):\n    follower_id=session['user_id']\n    if uid==follower_id:\n        flash('You cannot follow yourself.','error')\n        return redirect(url_for('profile'))\n    conn=db(); target=conn.execute('SELECT id,name,banned FROM users WHERE id=?',(uid,)).fetchone()\n    if not target or target['banned']:\n        conn.close(); abort(404)\n    try:\n        conn.execute('INSERT INTO follows(follower_id,following_id) VALUES(?,?)',(follower_id,uid))\n        conn.commit(); flash(f'You are now following {target[\"name\"]}. Contact details are unlocked.','success')\n    except sqlite3.IntegrityError:\n        conn.rollback(); flash('You already follow this student.','success')\n    finally:\n        conn.close()\n    return redirect(url_for('teammate',uid=uid))\n\n@app.route('/unfollow/<int:uid>', methods=['POST'])\n@login_required\ndef unfollow_user(uid):\n    if uid==session['user_id']:\n        return redirect(url_for('profile'))\n    conn=db(); conn.execute('DELETE FROM follows WHERE follower_id=? AND following_id=?',(session['user_id'],uid)); conn.commit(); conn.close()\n    flash('You unfollowed this student. Their contact details are locked again.','success')\n    return redirect(url_for('teammate',uid=uid))\n\n"""+marker
if marker not in s: print('route marker not found')
s=s.replace(marker,route,1)
# Make contact statement on find teammate more accurate
s=s.replace("<a class=\"btn\" href=\"/teammate/{{r.user.id}}\">View profile & contact</a>","<a class=\"btn\" href=\"/teammate/{{r.user.id}}\">View profile & follow</a>")
# Add explanatory text to home profile card
s=s.replace("<p class=\"muted\">Showcase your skills, interests, branch, year and contact details.</p>","<p class=\"muted\">Showcase your skills, interests, branch and year. Contact details are unlocked after someone follows you.</p>")
# Ensure db initialized on import for packaged execution too (currently only __main__). Insert before errorhandler.
needle="""@app.errorhandler(404)\n"""
insert="""# Initialize the database when the module is imported as well as when run directly.\ninit_db()\n\n@app.errorhandler(404)\n"""
s=s.replace(needle,insert,1)
p.write_text(s)
