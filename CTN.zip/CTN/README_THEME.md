# Campus Talent Network — Dark / Light Theme

Added a site-wide Light/Dark theme system without changing the existing application architecture.

## Theme behavior
- Theme toggle is available in the navbar on every page, including login/register.
- Selection is saved in browser `localStorage` under `ctn-theme`.
- The saved theme is applied in the document `<head>` before the stylesheet to minimize light-mode flashing.
- Dark theme uses dedicated surface, text, border, input, alert, button and graph-friendly colors; it does not invert the page.
- Existing state/district-only location system is unchanged. No GPS feature was reintroduced.

## Run
```powershell
py -m venv venv
venv\\Scripts\\activate
python -m pip install -r requirements.txt
python app.py
```
Then open http://127.0.0.1:5000
