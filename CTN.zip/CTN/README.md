# Campus Talent Network

Local Flask + SQLite student collaboration prototype. The existing architecture is preserved; the enhanced version extends the current `app.py`, database, routes and inline templates rather than rebuilding the application.

## Implemented

- Complementary skill-gap matching and explainable candidate recommendations.
- Work style, commitment, goals, communication preference and working-hour profile fields.
- Smart Project Brief Builder with project information, problem/objective, required/preferred skills, roles, time, deadline, style, communication, goal and commitment.
- Data-derived Project DNA: difficulty, time commitment, collaboration and deadline pressure.
- Team chemistry dimensions: technical fit, complementary skills, work style, communication, time compatibility, goal alignment and commitment.
- Dynamic team weakness/skill-gap analysis based on current project members.
- Visual skill tree / skill-level bars.
- Team skill-gap and availability visualizations.
- Project personality choices used as project metadata.
- Explainable recommendation reasons.
- Existing teammate search, saved searches, follow/contact unlocking, ratings and reporting are retained.
- Full light/dark theme toggle with local-storage persistence and early theme initialization to reduce theme flash.
- Project membership routes so team analysis can update as members join/leave.
- Existing database is migrated in place with new fields/tables.

## Run

```powershell
py -m venv venv
venv\Scripts\activate
python -m pip install -r requirements.txt
python app.py
```

Open `http://127.0.0.1:5000`.

## Important

The requested “AI Team Architect / Build My Team” feature is intentionally **not** implemented. The platform recommends candidates and analyzes teams, but does not automatically construct a separate AI-generated team.

## Testing performed before delivery

- Python syntax compilation of the modified `app.py`.
- SQLite schema migration checks for the new user/project fields and `project_members` table.
- Existing database data was preserved.
- The code was statically reviewed for the previously observed `/find-teammate` GET variable issue and the `/add-project` undefined-user issue; the enhanced version removes those failure paths.

A full Flask browser/server test could not be executed in the build environment because Flask is not installed there. After installing `requirements.txt`, the application should be run locally and the final browser checklist in the original specification should be exercised.
